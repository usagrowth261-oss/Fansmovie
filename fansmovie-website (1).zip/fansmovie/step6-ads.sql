-- =========================================================
-- FansMovie — STEP 6 migration: ad slots, sponsored movies,
-- ad-free plan flag
-- Run this in: Supabase Dashboard → SQL Editor → New query
-- (Run this AFTER schema.sql and steps 2–5)
-- Safe to run once; uses IF NOT EXISTS / ON CONFLICT guards.
-- =========================================================

-- 1. AD SLOTS ----------------------------------------------------------
-- One row per reusable ad placement on the site. This is the
-- "centralized configuration" the admin can (eventually) edit without
-- touching page code — see js/ads.js, which reads this table and
-- decides what to render for each `data-ad-slot="..."` element.
create table if not exists public.ad_slots (
  slot_key    text primary key,
  name        text not null,
  placement   text not null,           -- human-readable location, for the admin list
  enabled     boolean not null default false,
  device      text not null default 'both' check (device in ('both','desktop','mobile')),
  provider    text not null default '',    -- e.g. 'google_adsense'; empty = no network configured
  network_code text not null default '',   -- e.g. an AdSense client/ad-unit ID; empty = placeholder only
  updated_at  timestamptz not null default now()
);

insert into public.ad_slots (slot_key, name, placement) values
  ('top_banner',        'Top banner',            'Site header / top of homepage'),
  ('homepage_sections',  'Homepage section break','Between homepage movie rows'),
  ('content_section',    'Content section banner','Between content sections on secondary pages'),
  ('movie_sidebar',      'Movie details sidebar', 'Movie details page sidebar (desktop)'),
  ('movie_player',       'Movie player area',     'Below the video player'),
  ('movie_banner',       'Movie details banner',  'Bottom of movie details page'),
  ('footer',             'Footer',                'Site-wide footer')
on conflict (slot_key) do nothing;

update public.ad_slots set device = 'desktop' where slot_key = 'movie_sidebar' and device = 'both';

alter table public.ad_slots enable row level security;

-- Anyone can read slot config (needed to decide what to render — this
-- is placement config, not sensitive data). Only admins can change it.
drop policy if exists "public_read_ad_slots" on public.ad_slots;
create policy "public_read_ad_slots" on public.ad_slots
for select to anon, authenticated using (true);

drop policy if exists "admin_write_ad_slots" on public.ad_slots;
create policy "admin_write_ad_slots" on public.ad_slots
for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));


-- 2. SPONSORED MOVIES ----------------------------------------------------
alter table public.movies add column if not exists sponsored boolean not null default false;
comment on column public.movies.sponsored is 'Admin-controlled flag for paid/promotional placements. The UI must always show a visible "Sponsored" label when true — never disguise it as ordinary editorial content.';
-- No new RLS needed: this column is covered by the existing movies
-- policies from schema.sql (public read on published rows, admin write).


-- 3. AD-FREE PLAN FLAG ----------------------------------------------------
alter table public.subscription_plans add column if not exists ad_free boolean not null default false;
comment on column public.subscription_plans.ad_free is 'Whether subscribers to this plan see no ads. Defaults to false — Premium is NOT assumed ad-free unless you deliberately turn this on for a plan.';
-- No new RLS needed: already covered by subscription_plans policies
-- from step5-premium.sql (public read on active plans, admin write).
