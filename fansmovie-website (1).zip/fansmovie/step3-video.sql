-- =========================================================
-- FansMovie — STEP 3 (optional) database polish
-- Run this in: Supabase Dashboard → SQL Editor → New query
-- Nothing here is required for Step 3 to work — video_url,
-- trailer_url, poster_url, published and created_at already
-- exist from schema.sql (Step 1). This just documents the
-- video fields' intended use and speeds up the public catalog
-- query. Safe to run once.
-- =========================================================

comment on column public.movies.video_url is
  'Playback/stream URL for the full movie, from an external video streaming service (e.g. Bunny Stream, Cloudflare Stream, Mux). This is the field the FansMovie site calls the "video stream URL". Never store large video files in Supabase — this column holds a link, not a file.';

comment on column public.movies.trailer_url is
  'Playback URL for the trailer clip, same rules as video_url.';

comment on column public.movies.poster_url is
  'Public URL of the poster image. Set automatically when an admin uploads a file via the admin panel (stored in the "posters" Supabase Storage bucket), or can be pasted manually as an external image URL.';

-- Speeds up the public site's main query: published movies, newest first.
create index if not exists movies_published_created_idx
  on public.movies (published, created_at desc);
