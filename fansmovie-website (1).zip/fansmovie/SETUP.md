# FansMovie — Supabase setup (admin + database)

This connects the admin dashboard and the public catalog to a real
Supabase project. Nothing else about the site changes — same pages,
same design. Do these steps in order.

---

## 1. Create the Supabase project

1. Go to https://supabase.com → sign in → **New project**.
2. Pick an organization, name it (e.g. `fansmovie`), set a database
   password (save it somewhere safe), pick a region, and create it.
3. Wait for provisioning to finish (~2 minutes).

## 2. Run the database schema

1. In your project, open **SQL Editor** (left sidebar) → **New query**.
2. Open `schema.sql` from this project folder, copy its entire contents,
   paste into the query editor, and click **Run**.
3. Confirm it worked: go to **Table Editor** — you should see two new
   tables, `movies` and `admins`, both with RLS enabled (a shield icon).

This creates:
- `movies` — title, description, poster_url, trailer_url, video_url,
  year, language, genre, category, duration, rating, tier, published.
- `admins` — a whitelist of which logged-in users are allowed to manage
  the catalog.
- Row Level Security policies so that: anyone can read `published = true`
  movies, but only rows listed in `admins` can read unpublished movies,
  or insert/edit/delete anything.

## 3. Turn off public sign-ups (important)

FansMovie's admin login uses Supabase's normal email/password auth, but
you don't want random visitors creating accounts.

1. Go to **Authentication → Settings** (sometimes under **Providers**
   depending on the dashboard version).
2. Turn **off** "Allow new users to sign up" / "Enable email signups"
   for public self-registration.
3. Leave the **Email** provider itself enabled — you (the owner) still
   need it to sign in.

## 4. Create your admin account

1. Go to **Authentication → Users → Add user → Create new user**.
2. Enter your email and a password. Confirm the user (skip email
   confirmation, or auto-confirm — there's a checkbox for this).
3. Copy the new user's **UUID** shown in the users list.
4. Go back to **SQL Editor** and run, replacing the UUID:

   ```sql
   insert into public.admins (user_id) values ('paste-the-uuid-here');
   ```

This is the only step that grants admin rights — it's a manual, one-time
action by you, and there is no button in the website itself that can do
this (by design, so no one can grant themselves access).

You can repeat step 4 for additional admins later.

## 5. Get your API keys

1. Go to **Settings → API**.
2. Copy the **Project URL** and the **anon public** key.
   (Never use the `service_role` key in front-end code — it bypasses RLS.)

## 6. Configure the website

Open `js/supabase-config.js` and replace the two placeholder values:

```js
const SUPABASE_URL = "https://xxxxxxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOi...";        // the anon public key
```

Save the file. That's the entire configuration step — no other file
needs editing.

## 7. Test it

1. Open `admin.html` in a browser.
   - If the config above is still filled with placeholders, you'll see
     a "Supabase not configured" screen instead of the dashboard —
     that's expected, and confirms the site isn't pretending to be
     connected.
   - Once configured, you'll see a login form. Sign in with the admin
     email/password from step 4.
2. Add a movie, publish it, then open `index.html` or `movies.html` —
   it should appear in the public catalog automatically.
3. Unpublish it from the admin panel — it should disappear from the
   public pages (a page refresh may be required, since the public pages
   fetch on load, not live).

---

## What's now real vs. still a placeholder (after Step 1)

| Piece | Status |
|---|---|
| Movie storage (title, description, year, language, genre, duration, rating, category, tier) | **Real** — Postgres table via Supabase |
| Publish/unpublish | **Real** — a `published` column, enforced by RLS, not just hidden in the UI |
| Admin login | **Real** — Supabase Auth (email/password) + an `admins` whitelist table |
| Public catalog pages | **Real** — read live from the database, published rows only |
| Poster/trailer/video files | **Still placeholder** — the admin form takes a URL, but there is no file upload / storage bucket yet. You'd host the actual media file somewhere (e.g. Supabase Storage, a CDN) and paste its URL in |
| Payments, ads, real ad network | **Untouched** — explicitly out of scope for this pass |

If a public page fails to reach Supabase (not configured yet, or a
network error), it shows a small on-page notice and falls back to the
original sample placeholder catalog, so the site never looks broken —
but it will say clearly that it isn't showing real database content.

---

# STEP 2 — Poster storage + video URL structure

This step makes poster uploads real (Supabase Storage) and prepares
the video/trailer fields for a real streaming service. It does not
touch design, and does not add payments or ads.

## 1. Run the Step 2 SQL migration

1. Open **SQL Editor → New query** in your Supabase project.
2. Open `step2-storage.sql` from this project folder, copy its entire
   contents, paste it in, and click **Run**.
3. This will:
   - add a `poster_path` column to `movies` (used internally to
     replace/delete the right file when a poster is updated),
   - create a public **`posters`** Storage bucket,
   - add Storage policies so **anyone can view** poster images, but
     **only accounts listed in `admins`** can upload, replace, or
     delete them.
4. Confirm it worked: **Storage** in the sidebar should now show a
   `posters` bucket.

## 2. Nothing else to configure for posters

Your existing `js/supabase-config.js` values (Project URL + anon key)
are reused automatically — poster uploads go through the same
connection. Once step 1 above is run, uploading a poster in
`admin.html` → Add/Edit Movie will actually store the file in
Supabase Storage and save its public URL on the movie record.

## 3. Video and trailer — what's real now, what's still needed

The `movies` table already has `video_url` and `trailer_url` columns
(from Step 1), and the admin form, the public movie page, and the
HTML5 player are all wired to read and write them. What's genuinely
**not** built, on purpose:

- **No video file upload button**, and no Supabase Storage bucket for
  video. Supabase Storage has no video streaming features (no
  adaptive bitrate, no transcoding, no protection against someone
  copying the direct file URL), so it's the wrong tool for movie
  files even though it works fine for small poster images.
- **No streaming service is connected yet.** You need to pick one and
  create an account with it separately. Reasonable options, roughly
  cheapest/simplest to most full-featured:
  - **Bunny Stream** — inexpensive, simple upload + playback URL API.
  - **Cloudflare Stream** — pay-per-minute-stored + per-minute-viewed,
    built-in player, good if you're already on Cloudflare.
  - **Mux** — developer-focused, strong analytics, usage-based pricing.
  - **YouTube (unlisted) or Vimeo (private/domain-restricted)** — free
    or low-cost if you're OK with their players/branding and terms of
    service for the kind of content you're hosting.

  Whichever you pick: upload the movie file there, get the playback
  URL it gives you, and paste that URL into the **Video URL / stream
  URL** field in the admin form — nothing else about the site needs
  to change for a plain `.mp4` URL. If the service instead gives you
  an **HLS stream (a `.m3u8` URL)**, the current `<video>` element will
  play it natively in Safari, but Chrome/Firefox/Edge need a small
  extra library (`hls.js`) to play HLS — that wiring is not done yet;
  say the word when you're ready and it can be added as a small,
  separate change.

## What's now real vs. still a placeholder (after Step 2)

| Piece | Status |
|---|---|
| Poster upload | **Real** — uploads to a Supabase Storage bucket, saves the public URL + path on the movie row, old file is deleted when replaced |
| Poster storage security | **Real** — RLS-style Storage policies: public read, admin-only write/delete |
| Video/trailer fields | **Structure only** — real DB columns + a working `<video>` player pointed at whatever URL is saved, but no upload button and no streaming service connected yet (see above) |
| Admin-only access to uploads/edits/deletes | **Real** — enforced by the same `admins` table + RLS from Step 1, now also covering Storage |
| Fake/demo video playback | **Removed for real movies** — a database movie with no `video_url` set shows "no video source yet" instead of silently playing the sample clip. The sample clip only ever plays for the built-in placeholder catalog (when Supabase isn't connected) |

---

# STEP 3 — Real video streaming (player + integration)

This step upgrades the player to handle real streaming URLs properly
and adds a proper "video management" area in the admin panel. It does
**not** connect an actual video hosting account for you — that
requires you to sign up with one (see below) — but everything on the
FansMovie side is ready for whichever URL that service gives you.

## What changed

- **Player**: now loads the movie's stored `video_url` as soon as the
  page opens (no download happens until playback starts, since
  `preload="none"` is kept), shows a spinner while buffering, and
  shows a clean **"Video currently unavailable"** message — instead
  of a blank/broken player — both when no URL is set yet and when a
  set URL fails to load. Added `playsinline` so it plays inline on
  iPhone/iPad instead of forcing fullscreen. Play/pause, volume,
  seek bar and fullscreen are the browser's native `<video controls>`
  — already fully working on desktop and mobile, nothing custom was
  needed there.
- **Admin panel**: the Video URL and Trailer URL fields are now in a
  labeled "Video management" section, with a **Preview** button next
  to each that plays the pasted URL right there in the form — so you
  can sanity-check a stream works before publishing. The Manage
  Movies table also now shows a **Video: Set / Missing** column so
  you can see at a glance which titles still need a stream URL.
- **Database**: `video_url`, `trailer_url`, `poster_url`, `published`,
  `created_at` were already in place from Steps 1–2. Optional
  `step3-video.sql` just adds column comments (documentation) and an
  index to speed up the "published movies, newest first" query — run
  it if you want, nothing breaks if you skip it.
- **Security**: unchanged from Steps 1–2 — only `js/supabase-config.js`'s
  **anon public key** is ever used client-side; RLS + the `admins`
  table are what actually decide who can write. No service-role key
  or other secret appears anywhere in the site's code.

## Recommended external video service: Bunny Stream

**Why**: it's built specifically for video (not general file storage),
handles encoding and adaptive playback for you, has by far the
lowest storage/bandwidth pricing of the mainstream options, and its
API is simple enough to fit this project without a lot of extra
infrastructure. Cloudflare Stream and Mux are equally legitimate if
you'd rather stay in that ecosystem or want deeper analytics — the
integration pattern below is the same for all three (you get a
playback URL, you paste it into FansMovie).

**1. Create the account**
Sign up at bunny.net → create a **Stream** library (separate from
their general CDN storage product). This gives you a Library ID and
an API key in that library's dashboard.

**2. Upload a movie**
Either drag-and-drop through the Bunny dashboard, or use their upload
API. For files under a couple hundred MB, the dashboard is easiest
to start with.

**3. Get the playback URL**
Once a video finishes processing, Bunny gives you a direct HLS
playback URL (an `.m3u8` link) and/or an MP4 fallback URL depending
on your library settings.

**4. Connect it to FansMovie**
No FansMovie code changes needed for a plain link — open
`admin.html` → Edit that movie → paste the URL into **Video stream
URL** → hit **Preview before publishing** to confirm it plays → Save.

**5. Credentials**
Only *you* need Bunny credentials, to upload/manage videos in their
dashboard. FansMovie itself never touches or stores your Bunny API
key anywhere — it only ever stores the resulting playback URL, in
the `movies.video_url` column, same as any other link.

**Direct upload from the FansMovie admin panel?** Not built in this
step, on purpose. Bunny does support secure direct/resumable uploads
from a browser, but generating the required signed upload token has
to happen on a server that holds your private Bunny API key — never
in front-end JavaScript, or the key would be exposed to every visitor.
That means it needs a small server-side piece (e.g. a Supabase Edge
Function) to generate the signature. That's a reasonable next
addition, but it's a separate, testable piece of work — say the word
and it can be built as its own step once you have a Bunny account to
develop against.

**Format note**: an `.m3u8` (HLS) URL — Bunny and Cloudflare Stream's
default output — plays natively in Safari, but Chrome/Firefox/Edge
need a small extra library (`hls.js`, ~50KB) to play HLS in a plain
`<video>` tag. That's not added yet either, for the same reason: no
point wiring it in before there's a real HLS URL to test it against.
If your library outputs a plain `.mp4` URL instead, no extra library
is needed at all — the current player already handles it.

**Bandwidth/storage considerations**: video is billed by storage
(GB stored) and by bandwidth/streaming (GB delivered to viewers) —
for context, an hour of decent-quality video is roughly 1–3 GB, so
costs scale with both catalog size and how many people actually watch.
Check current pricing directly on the provider's site before
committing, since it changes over time.

## What's now real vs. still a placeholder (after Step 3)

| Piece | Status |
|---|---|
| Player loading/error/unavailable states | **Real** — reflects the actual `video_url` value and actual load success/failure, never fakes success |
| Mobile inline playback | **Real** — `playsinline` added |
| Native play/pause/volume/seek/fullscreen | **Real** — browser-native `<video controls>`, already fully functional |
| Admin video management section + preview | **Real** — paste a URL, preview it in the form before saving |
| Manage-table video status column | **Real** — reads directly from `video_url` |
| Actual video hosting account | **Not connected** — you need to sign up with Bunny Stream (or Cloudflare Stream / Mux) yourself; nothing to configure on the FansMovie side beyond pasting the resulting URL |
| Direct browser upload of movie files | **Not built** — needs a server-side signing step (e.g. Supabase Edge Function); URL-paste is the only path for now |
| HLS (`.m3u8`) playback on Chrome/Firefox | **Not built** — needs `hls.js`; add once you have a real HLS URL to test against |

---

# STEP 4 — Real user accounts, favorites, watchlist, watch history

This step adds visitor sign-up/login and makes Favorites, Watchlist,
Recently Watched and Continue Watching genuinely persistent per user,
backed by Supabase — nothing here is stored only in the browser tab
anymore. Design is unchanged; the "Login" header button now goes to
a real `account.html` instead of showing a placeholder toast.

## 1. Run the Step 4 SQL migration

Open **SQL Editor → New query**, paste in the full contents of
`step4-users.sql`, and run it. This creates:

- `profiles` — one row per signed-up user (auto-created on sign-up
  by a trigger on `auth.users`), holding just their id/email/created_at.
- `favorites`, `watchlist` — one row per (user, movie).
- `watch_history` — "Recently Watched"; one row per (user, movie),
  the timestamp is bumped on rewatch instead of creating duplicates.
- `watch_progress` — "Continue Watching"; one row per (user, movie)
  in progress; the app deletes the row once a title is ~95%+ complete.

All five tables have Row Level Security enabled with "own rows only"
policies — see part D below.

## 2. Re-enable public sign-ups (important — reverses Step 1's advice)

Step 1's setup told you to **turn off** public sign-ups, as an extra
precaution while only admin login existed. Now that regular visitors
need to create accounts, go to **Authentication → Providers → Email**
and make sure sign-ups are **allowed** again.

**Why this is still safe for admin access:** admin permissions were
never based on "signups are disabled" — they're based on the
`admins` whitelist table from Step 1, checked by Row Level Security
on every request (see `schema.sql`). There is no insert/update/delete
policy on `admins` at all, so no signed-up user — no matter how they
registered — can ever add themselves to it. The only way to become an
admin is still you manually running an `insert` in the SQL editor.
Regular sign-ups and admin access are fully independent systems.

## 3. Decide on email confirmation

In **Authentication → Providers → Email**, "Confirm email" is your
choice:
- **On** (default): new users must click a confirmation link before
  they can log in. `account.html` already handles this — after
  sign-up it shows "check your email to confirm."
- **Off**: accounts are usable immediately after signing up.

## 4. Password reset emails

Password reset uses Supabase's built-in email flow
(`resetPasswordForEmail`) — no extra configuration is required for it
to send, though for production use you'll eventually want to
customize the email templates and sender domain under
**Authentication → Email Templates** (optional, not required for it
to work).

## What's now real vs. still a placeholder (after Step 4)

| Piece | Status |
|---|---|
| Sign up / log in / log out | **Real** — Supabase Auth |
| Forgot password / reset | **Real** — sends a real reset email, includes the "set new password" landing flow |
| Favorites, Watchlist | **Real** — persisted in Supabase, survive logout/login, on any device |
| Recently Watched | **Real** — one row per movie, timestamp bumped on rewatch (no duplicates) |
| Continue Watching | **Real** — playback position saved every ~5s while playing and on pause, resumes on return, auto-removed at ~95% complete and logged to Recently Watched instead |
| Account page | **Real** — shows email + member-since date, real Logout |
| "Log in to use this" prompts | **Real** — favorites/watchlist/etc. show a clean prompt (a message + Log In/Sign Up link, or a toast on card buttons) instead of silently working locally when logged out |
| Admin vs. regular user separation | **Unchanged and still enforced** — the `admins` table + RLS, independent of the sign-up setting above |
| Anonymous/sample-mode browsing | **Unaffected** — browsing published movies never required an account and still doesn't |

## E) What to test

1. **Sign up** a test account on `account.html` → confirm email if
   required → log in.
2. On `movies.html` or `movie.html`, click a heart icon / **Add to
   Favorites** / **Add to Watchlist** → check the row appears in the
   `favorites` / `watchlist` tables in the Supabase Table Editor.
3. Go to `favorites.html` → confirm the same titles show up in the
   **Favorites** / **Watchlist** tabs.
4. Play part of a movie on `movie.html`, leave the page (or close the
   tab) partway through → reopen the same movie → it should resume
   near where you left off, and it should also appear under **Continue
   Watching** on `favorites.html`.
5. Watch a title to the end (or manually seek near the end) → confirm
   it disappears from Continue Watching and appears in **Recently
   Watched** instead.
6. **Log out**, then **log back in** with the same account → favorites/
   watchlist/history should all still be there.
7. Open the site in a **private/incognito window** and confirm
   Favorites/Watchlist/etc. all show the "Log in to see your list"
   prompt rather than someone else's data or an error.
8. Create a **second** test account and confirm it never sees the
   first account's favorites/watchlist/history (this is what the RLS
   policies in part D are for — worth deliberately checking once).
9. Confirm `admin.html` still works exactly as before, and that
   logging in there with a non-admin account is still rejected.

## F) Still needs backend configuration

- You must actually run `step4-users.sql` and flip the sign-ups
  setting (parts 1–2 above) — nothing above works until then.
- Decide on email confirmation on/off (part 3).
- If you want nicer-looking password reset/confirmation emails later,
  customize them under Authentication → Email Templates — optional.
- Everything else needed for this step is done; no additional
  external service (beyond Supabase, already in use) is required for
  accounts/favorites/watchlist/history/continue-watching.

---

# STEP 5 — Premium membership & payments

This step adds real subscription plans, a real (but not-yet-connected)
payment flow via Stripe, and — importantly — moves the actual paywall
check into the database itself, not just the page's JavaScript.

## What changed, and why it's structured this way

**The security-critical change:** in Steps 1–3, a movie's `video_url`
lived directly on the `movies` row, which anyone can read (that's how
browsing works). That was fine while everything was free, but it meant
a Premium movie's real stream URL was technically fetchable by anyone
calling the Supabase API directly, no matter what the UI showed. Row
Level Security is per-row, not per-column, so the fix is structural:
`step5-premium.sql` moves `video_url` into its own table,
`movie_streams`, with its own RLS policies:

- Free movies' stream URL: readable by anyone.
- Premium movies' stream URL: readable **only** by a signed-in user
  with a row in `subscriptions` where `status = 'active'` **and**
  `current_period_end > now()`, checked live on every request.
- Admins: full access (that's what the admin panel uses).

This means the paywall holds even if someone bypasses the website
entirely and calls the Supabase API directly — exactly what was asked
for. The trade-off: this is a real schema change (it drops the old
`movies.video_url` column after copying its data into the new table),
so `step5-premium.sql` must be run for movie playback to keep working
at all, including for your existing Free titles.

**The payment-integrity change:** `subscriptions` and `transactions`
have **no insert/update/delete policy for regular users, and no
general-purpose one for admins either.** The only two ways a row in
either table can ever be created or changed are:
1. The `stripe-webhook` Edge Function, using the Supabase
   service-role key (which only exists server-side, in that
   function's environment) — this is what a real payment updates.
2. The `admin_grant_subscription()` SQL function, callable only by
   accounts in the `admins` table, which always records itself as
   `payment_provider = 'manual_admin_grant'` — never disguised as a
   real Stripe payment. This is the "clearly controlled administrative
   process" the brief asked for.

Nobody — not a regular user, not even an admin working from the
browser — can just flip a row to `active` and grant themselves or
someone else free Premium access outside of that one controlled path.

## 1. Run the Step 5 SQL migration

Run `step5-premium.sql` in the SQL Editor. It will:
- Move `video_url` into the new `movie_streams` table (see above) and
  drop it from `movies`.
- Create `subscription_plans` (seeded with placeholder Monthly/Yearly
  rows at price 0 — edit real prices after connecting Stripe, see
  step 3 below), `subscriptions`, `transactions`.
- Add all the RLS policies described above.
- Add `has_active_subscription()` and `admin_grant_subscription()`.

## 2. Recommended payment provider: Stripe

**Why:** Stripe Billing is built specifically for recurring
subscriptions (handles renewal, retries, proration, and cancellation
for you), has first-class test mode, and — critically for "don't
store card data" — its Checkout page means FansMovie's own code never
touches a card number at all; Stripe handles PCI compliance entirely
on their hosted page. Every event needed here (payment succeeded,
payment failed, subscription renewed/cancelled) is a well-documented
webhook.

## 3. Stripe account setup

1. Create a Stripe account at stripe.com. You'll start in **Test
   mode** automatically (there's a toggle in the dashboard) — build
   and test everything here first, per the brief's requirement.
2. **Products → Add Product** — create one product per plan (e.g.
   "FansMovie Premium — Monthly", "...— Yearly"). For each, add a
   recurring **Price** with your real amount and currency, and billing
   interval (month/year). Copy each Price's ID (`price_...`).
3. In Supabase, open the `subscription_plans` table and paste the
   matching Stripe Price ID into `provider_price_id` for the Monthly
   and Yearly rows, and set a real `price`/`currency` (this is what
   `premium.html` displays — it's independent of what Stripe charges,
   so keep them in sync manually, or treat the Stripe Price as the
   source of truth and update this table to match).
4. **Developers → API keys** — copy the **Secret key** (`sk_test_...`
   in test mode). This is the one credential that must never appear
   in any frontend file — it only ever goes into the Edge Function's
   environment (next section).

## 4. Deploy the two Edge Functions

The code is already written — `supabase/functions/create-checkout-session/index.ts`
and `supabase/functions/stripe-webhook/index.ts` — but **not deployed**.
Using the Supabase CLI (`npm install -g supabase`, then `supabase login`
and `supabase link --project-ref <your-project-ref>` from this project
folder):

```
supabase functions deploy create-checkout-session
supabase functions deploy stripe-webhook
```

Then set the secrets these functions need (server-side only — this is
exactly what keeps them out of the frontend):

```
supabase secrets set STRIPE_SECRET_KEY=sk_test_...
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...   (from step 5 below)
supabase secrets set SITE_URL=https://your-fansmovie-domain.com
```

(`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are provided
automatically to Edge Functions by Supabase — you don't set those
yourself.)

## 5. Connect the Stripe webhook

1. In Stripe (test mode): **Developers → Webhooks → Add endpoint**.
2. Endpoint URL: your deployed function's URL, shown after deploying
   — looks like `https://<project-ref>.supabase.co/functions/v1/stripe-webhook`.
3. Events to send: `checkout.session.completed`,
   `invoice.payment_succeeded`, `invoice.payment_failed`,
   `customer.subscription.updated`, `customer.subscription.deleted`.
4. Stripe shows you a **Signing secret** (`whsec_...`) — that's the
   `STRIPE_WEBHOOK_SECRET` from step 4 above.

## 6. How it all fits together

- **Successful payment**: user clicks Subscribe on `premium.html` →
  `create-checkout-session` makes a Stripe Checkout Session → browser
  redirects to Stripe's hosted page → user pays → Stripe redirects
  back to `account.html` → Stripe also calls `stripe-webhook` with
  `checkout.session.completed`, which writes the real `subscriptions`
  and `transactions` rows using the service-role key.
- **Failed payment**: `invoice.payment_failed` writes a `transactions`
  row with `status = 'failed'`. Access isn't revoked immediately —
  Stripe retries failed invoices on its own schedule; access is only
  downgraded once Stripe actually cancels/unpays the subscription
  (`customer.subscription.updated`/`deleted`), which the webhook also
  handles.
- **Expiry**: handled two ways at once — reactively, Stripe sends
  `customer.subscription.updated`/`deleted` on renewal, cancellation,
  or non-payment, which updates `subscriptions.status`; and
  defensively, the `movie_streams` RLS policy itself checks
  `current_period_end > now()` on every single request, so access is
  correctly time-gated even if a webhook were ever delayed or missed.

## 7. Test mode

Everything above uses Stripe **test mode** keys — no real charges
happen. Use Stripe's test card `4242 4242 4242 4242`, any future
expiry date, any CVC, any postal code. Stripe's dashboard is clearly
labeled "Test mode" the whole time you're using test keys — there's
no separate flag needed in FansMovie's code, since which Stripe key
you deploy is what decides it.

## What's now real vs. still not live (after Step 5)

| Piece | Status |
|---|---|
| Plans, pricing structure (monthly/yearly, configurable price/currency) | **Real** — `subscription_plans` table, no hard-coded price anywhere |
| Premium/Free flag per movie, admin toggle | **Real** — already existed (`movies.tier`), unchanged |
| Paywall enforcement | **Real, and enforced in the database** — `movie_streams` RLS, not just hidden buttons |
| `premium.html` — real plans, price, current status | **Real** — reads live from Supabase |
| Account page subscription section | **Real** — plan, status, start/expiry, payment status |
| Movie page Premium badge + Subscribe-to-Watch state | **Real** |
| Admin subscription overview (active/expired counts, recent transactions, plan active toggle) | **Real** — read-only on subscriptions/transactions by design (see security note above) |
| Stripe Checkout + webhook code | **Written, not deployed** — needs the CLI deploy + secrets steps above |
| Actual Stripe account / real prices | **Not connected** — you need to do steps 2–5 above |
| Refund/Terms/Privacy legal text | **Placeholders only** — see part F below |

## F) What you need to test once Stripe is connected

1. Subscribe with the Stripe test card above → confirm you land back
   on `account.html` and it shows an **Active** subscription with the
   correct plan/dates.
2. Check the Supabase `subscriptions` and `transactions` tables — a
   real row should exist, `payment_provider = 'stripe'`.
3. Open a Premium movie you set a stream URL for → confirm it now
   plays instead of showing "Subscribe to Watch."
4. In Stripe's test dashboard, cancel the test subscription → confirm
   the webhook fires and `subscriptions.status` updates → reload the
   Premium movie page → confirm it goes back to "Subscribe to Watch."
5. Log in as a **non-subscribed** account and try fetching a Premium
   movie's `movie_streams` row directly via the Supabase REST API
   (e.g. with a tool like curl/Postman, using that user's anon-key
   session) — confirm it returns nothing. This is the check that
   proves the paywall is real, not just UI.
6. In `admin.html` → Subscriptions, confirm the active/expired counts
   and the test transaction show up.

## Legal pages — what you need to provide

I did not invent specific legal terms — `legal.html` now has clearly
marked **`[Placeholder]`** text in the Privacy and Refund/Cancellation
sections. Before accepting real payments you (ideally with a lawyer,
or at minimum by checking your local consumer-protection rules) need
to provide:
- Your actual cancellation and refund policy (can subscribers cancel
  anytime? do you offer refunds, and under what conditions/timeframe?).
- What personal data is retained, for how long, and how someone can
  request deletion of their account and data.
- A business name/contact address if your jurisdiction requires one
  on a terms/privacy page.
- Confirmation that Stripe's own terms (as your payment processor) are
  acceptable for your business and location.

---

# STEP 6 — Advertising & monetization readiness

This step makes every ad slot on the site driven by one real,
centralized config table instead of hard-coded markup, adds Sponsored
movies, and prepares (but does not activate) a Google AdSense
integration and a consent notice. **No ad network is connected. Every
slot on the live site still shows the same plain "Advertisement"
placeholder it always has** — visually nothing has changed — until you
deliberately configure and enable a slot.

## What changed

- **`ad_slots` table** (`step6-ads.sql`): one row per placement —
  top banner, homepage section break, movie player/sidebar/banner,
  generic content-section slot (used on movies/premium/about/contact/
  account pages), and footer. Each row has `enabled`, `device`
  (`both`/`desktop`/`mobile`), `provider`, and `network_code`.
- **`js/ads.js`**: on every page, finds every element with
  `data-ad-slot="..."` and decides what to render: the honest
  placeholder if the slot is disabled/unconfigured (the only state
  this ships in), or a real ad unit if an admin has filled in a
  provider + network code. Google AdSense is the only provider wired
  up (see below); anything else falls back to the placeholder rather
  than guessing.
- **Admin → Advertising**: lists every slot (placement, device,
  provider, "Configured"/"Not configured" status) with an
  Enable/Disable toggle, plus the two required notices — ad network
  integration is explicitly marked **pending approval/configuration**,
  and revenue shows **"Revenue data not connected"** rather than any
  number, because there is no real ad account to pull real numbers
  from.
- **Sponsored movies**: `movies.sponsored` boolean, an admin checkbox
  next to Publish, and a visible "SPONSORED" badge on cards wherever
  a sponsored title appears (including a dedicated slot on
  `premium.html`) — never disguised as ordinary editorial content.
- **Ad-free Premium, configurable per plan**: `subscription_plans.ad_free`
  (defaults `false` for every plan). Premium is **not** assumed
  ad-free — a plan only skips ad slots for its subscribers if you
  explicitly set `ad_free = true` on that plan in Supabase.
- **Consent notice**: a small dismissible banner (bottom of every
  page) noting that basic cookies/local storage are used to keep
  people signed in, and that it will be updated if advertising/
  analytics services are connected later. This is a starting UI
  structure, not a legal compliance claim — see the Privacy Policy
  placeholder note from Step 5 for what still needs real legal review
  (e.g. whether your audience requires a cookie-consent mechanism
  beyond this, such as GDPR/CCPA-specific consent).
- **Video ad readiness**: documented in a code comment directly above
  the player in `movie.html`, not implemented. See "Video advertising"
  below for why.

## 1. Run the Step 6 SQL migration

Run `step6-ads.sql`. It creates `ad_slots` (seeded with all 7 slots,
disabled), and adds `movies.sponsored` and `subscription_plans.ad_free`
(both default `false`, so nothing changes until you opt in).

## 2. Recommended ad network: Google AdSense

**Why:** it's the standard fit for a general content site without a
huge dedicated sales team — self-serve signup, works well with
display/banner-style placements like the slots already built here,
and `js/ads.js` already implements its official asynchronous loading
pattern (`adsbygoogle.js` loaded async, `<ins class="adsbygoogle">`
unit, `adsbygoogle.push({})`) so there's nothing left to build on the
code side once you're approved. For a site whose main content is
licensed video, **Google Ad Manager** (AdSense's bigger sibling) is
the natural next step once traffic justifies it, since it's also what
runs video ads via the IMA SDK (see below) — same account family.

## 3. Account setup & approval

1. Apply at adsense.google.com with FansMovie's real, live domain
   (AdSense reviews an actual reachable site — this can't be approved
   against a local prototype).
2. Google reviews the site for policy compliance — for FansMovie
   specifically, that means every title actually streamed must be
   genuinely owned/licensed (which is already this project's stated
   scope), site navigation must work, and required pages (Privacy,
   Terms — already present) must be in place.
3. **Approval is required before any ad will actually display** —
   this is not optional or skippable, and I'm not able to complete it
   for you since it requires your real business/site identity.
4. Once approved, AdSense gives you a **Publisher ID**
   (`ca-pub-XXXXXXXXXXXXXXXX`) — this is the only "code" involved, and
   it's meant to be public/client-side by design (it's not a secret,
   unlike the Stripe/Supabase keys from earlier steps).

## 4. Turning a slot on

Once approved, for each slot you want live: **Admin → Advertising**
won't let you type the code there by design (keeps this simple and
avoids building a rich text/script editor); instead, open the
`ad_slots` table in the Supabase Table Editor and set, per slot:
`provider = 'google_adsense'`, `network_code` = your Publisher ID (or
a specific ad-unit ID if you create per-slot units in AdSense), then
toggle `enabled = true` — either there or via the Enable button in
Admin → Advertising. `js/ads.js` picks it up on the next page load.

## 5. Video advertising — what's required, and why it's not built

FansMovie's player is a plain HTML5 `<video>` element, which has no
concept of "pause content, play a separate ad, then resume" — that
behavior needs a dedicated video-ad SDK sitting on top of it. The
standard one is the **Google IMA SDK** (works with Google Ad Manager
or any VAST/VMAP-compatible video ad network): it wraps the existing
player in an `AdDisplayContainer`, requests an ad from a VAST tag URL,
plays it in that container, and hands control back to the real
`<video>` element afterward. This requires a Google Ad Manager account
(a further step up from plain AdSense) and real VAST tag URLs — there
is nothing meaningful to build against without those, and doing so
would either be non-functional dead code or an actual (unwanted) fake
ad. The exact hook point — right before playback starts in the Watch
Now handler — is marked with a comment in `movie.html` for whenever
you're ready to connect it.

## What's now real vs. still not live (after Step 6)

| Piece | Status |
|---|---|
| Ad slot placements across the site | **Real** — 7 reusable slots, all driven by one config table |
| Enable/disable, desktop/mobile targeting, per-slot provider+code | **Real** — editable without touching page code |
| Google AdSense rendering path (async script + `<ins>` unit) | **Real, code-complete** — inert until a slot has real provider+code |
| Sponsored movies (flag, admin toggle, visible badge) | **Real** |
| Ad-free-for-Premium, per plan | **Real, opt-in, defaults off** |
| Consent banner | **Real, basic** — not a substitute for a full legal compliance review |
| Admin Advertising overview (slots, config status, revenue) | **Real** — revenue explicitly shows "not connected", never a fake number |
| Actual AdSense account / approval | **Not done** — requires your real live domain, outside what I can do here |
| Video/pre-roll advertising | **Documented only, not built** — needs Google Ad Manager + IMA SDK + real VAST tags first |

## G) How to test the ad placeholder system safely right now

1. Load any page — every ad slot should show the plain "Advertisement"
   label, exactly as before this step (nothing should look different).
2. In `admin.html` → Advertising, confirm all 7 slots list as
   "Disabled" / "Not configured", and the revenue box says "Revenue
   data not connected."
3. As a test (not a real network), set one slot's `provider` to
   `google_adsense` and `network_code` to any placeholder string
   directly in the Supabase Table Editor, then enable it from Admin →
   Advertising. Reload the page with that slot — you should see the
   AdSense script attempt to load and an empty ad unit (it won't show
   a real ad without a genuine, approved Publisher ID — that's
   expected and confirms the wiring without needing real approval
   yet). Set it back to disabled when done testing.
4. Mark one movie **Sponsored** in the admin, publish it, and confirm
   its "SPONSORED" badge shows on its card and it appears in
   `premium.html`'s Sponsored Movie section.
5. On a plan in `subscription_plans`, try setting `ad_free = true`,
   then check that a subscriber to that plan (with an active
   subscription) stops seeing ad slots rendered, while everyone else
   still does.

---

# STEP 7 — Production deployment readiness

This step doesn't add new user-facing features — it reviews and
hardens what already exists so it's genuinely deployable, and adds
the small set of files a real static-hosting deploy needs. Design and
functionality are unchanged.

## What I fixed

- **Broken poster images now fall back gracefully** — every poster
  `<img>` (cards and the movie details page) has an `onerror` handler
  that swaps to a generated placeholder instead of showing a broken-image
  icon if a poster URL 404s or is unreachable.
- **Global error safety net** (`js/app.js`) — any unexpected JS error
  or unhandled promise rejection is now caught and logged to the
  console only; it never surfaces a raw error/stack trace in the UI.
  Every deliberate error path elsewhere (login, checkout, favorites,
  etc.) already showed its own safe, specific message — this is only
  the last-resort catch-all for the unexpected.
- **SEO basics on every public page**: favicon (`favicon.svg`, brand-
  matched), a placeholder `<link rel="canonical">` (movie pages set
  it dynamically per-movie), `og:url`, and explicit
  `<meta name="robots" content="index, follow">`. Private pages
  (`account.html`, `favorites.html`, `admin.html`) already had
  `noindex` from earlier steps and are left alone.
- **`robots.txt`** (disallows admin/account/favorites, points at a
  sitemap) and a basic **`sitemap.xml`** — both use a clearly-labeled
  placeholder domain; nothing claims Google has indexed anything.
- **Reviewed all internal links/paths** — every CSS/JS reference is a
  relative path (no page hardcodes a domain or absolute root path),
  so the site works correctly regardless of which folder/domain it's
  deployed at.
- Confirmed there's no leftover debug code (`console.log`/TODO/dead
  code) — the sample-catalog fallback and demo video clip are the one
  intentional exception: they're the honest "Supabase isn't connected"
  state from Step 1, not test code, and they stop appearing the
  moment real configuration is in place.

## A) / B) Production build review — what's ready

| Check | Status |
|---|---|
| All 10 pages load and link correctly | **Reviewed, OK** — index/movies/movie/favorites/account/premium/contact/about/legal/admin, plus new 404.html |
| CSS/JS paths | **OK** — all relative, verified with a project-wide scan |
| Supabase config separation | **OK** — `js/supabase-config.js` holds only the public URL + anon key; now also generatable from env vars at build time (see below) |
| No fake payment/ad functionality presented as live | **OK** — Stripe checkout fails honestly if not deployed (Step 5); every ad slot defaults to the plain placeholder (Step 6); nothing before this step overstated status |
| Mobile/desktop layout | **Unchanged from earlier steps** — the responsive CSS grid/flex layout built in from Step 0 wasn't touched here |

## 2/E) Environment variables

**Frontend build (not secret):** `SUPABASE_URL`, `SUPABASE_ANON_KEY` —
see `.env.example`. `npm run build` runs `scripts/generate-config.js`,
which writes `js/supabase-config.js` from these two variables (or
leaves the safe "not configured" placeholder if they're unset). Set
them in your hosting platform's environment variable settings so each
environment (a staging Supabase project vs. your real production one,
for instance) can point somewhere different without editing code.
These two are genuinely public by Supabase's design — protected by
Row Level Security, not by being hidden — so this is about convenience
and multi-environment cleanliness, not secrecy.

**Real secrets — set only as Supabase Edge Function secrets, never
here:** `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
`SUPABASE_SERVICE_ROLE_KEY` (provided automatically), `SITE_URL` —
all already covered in Step 5's `supabase secrets set ...` commands.
There is nothing to add for Step 6 (Ad network's Publisher ID isn't a
secret either — same reasoning as the anon key).

## C) Recommended hosting: Netlify

**Why:** FansMovie is a plain multi-page static site (no framework,
no server-side rendering needed — every "backend" thing already goes
through Supabase directly from the browser). Netlify is built exactly
for that: drag-and-drop or git-based deploys, a generous free tier,
one-click environment variables for the build step above, automatic
free HTTPS via Let's Encrypt, and instant rollbacks. **Vercel** or
**Cloudflare Pages** are equally valid — same deployment shape
(connect a git repo, set two env vars, deploy); pick whichever you're
already comfortable with. `netlify.toml` is included for Netlify
specifically; the other two need no special config file at all for a
project this simple, just their build command set to `npm run build`
and publish directory set to `.` (project root) in their dashboard.

## D) Exact deployment steps (Netlify)

1. Push this project to a GitHub/GitLab/Bitbucket repo (or use
   Netlify's manual drag-and-drop deploy of the whole `fansmovie`
   folder if you don't want git — the build step still runs either way).
2. In Netlify: **Add new site → Import an existing project**, pick
   the repo. Build command and publish directory are already set via
   `netlify.toml` (`npm run build` / `.`).
3. **Site settings → Environment variables** — add `SUPABASE_URL` and
   `SUPABASE_ANON_KEY` (from Supabase Dashboard → Settings → API).
4. Deploy. Netlify gives you a `*.netlify.app` URL immediately over
   HTTPS — good for testing before attaching a real domain.
5. **Domain settings** → add your real domain → Netlify provisions
   HTTPS automatically once DNS points at it (this satisfies the
   HTTPS requirement — no manual certificate work needed).
6. Go back and replace `your-fansmovie-domain.example` in
   `robots.txt`, `sitemap.xml`, and the `<link rel="canonical">` /
   `og:url` tags with your real domain, then redeploy.
7. Update `SITE_URL` in your Supabase Edge Function secrets (Step 5)
   to match your real domain, so Stripe Checkout redirects land in
   the right place.

## F) Supabase settings to verify after deploying

- **Authentication → URL Configuration**: set Site URL and Redirect
  URLs to your real deployed domain (this is what makes password-reset
  email links land back on the live site instead of `localhost`).
- **Authentication → Providers → Email**: sign-ups enabled (Step 4),
  confirm-email setting is your deliberate choice.
- **Database → Row Level Security**: spot-check that RLS is enabled
  on `movies`, `movie_streams`, `favorites`, `watchlist`,
  `watch_history`, `watch_progress`, `subscriptions`, `transactions`,
  `subscription_plans`, `ad_slots`, `admins`, `profiles` — every
  table created across Steps 1–6 should show a lock icon in the
  Table Editor, not "Unrestricted."
- **Storage**: `posters` bucket exists and is public-read (Step 2).
- **Admin login**: confirm your admin account is in the `admins`
  table and `admin.html` rejects a non-admin login.
- **Premium access check**: as a non-subscribed test account, confirm
  a Premium movie shows "Subscribe to Watch," not the player.
- **Edge Functions**: both deployed, secrets set (Step 5).

## G) What is still not live

- The site is **not deployed anywhere yet** — these are the files and
  instructions to do that; I haven't hosted anything myself.
- Stripe is in **test mode** until you switch to live keys (your
  choice, once you're ready to accept real payments).
- No ad network is connected (Step 6) — still placeholder-only.
- `robots.txt`/`sitemap.xml`/canonical tags still reference the
  placeholder domain until you do step 6 above.
- Google hasn't indexed anything — nothing here claims otherwise;
  indexing happens after you deploy and (optionally) submit the
  sitemap in Google Search Console.

## Troubleshooting: env vars are set, redeployed, but it still says "not connected"

This means the build either didn't actually run `npm run build`, or ran
it without the variables reaching it. Check, in this order:

1. **Read the actual deploy log** (Netlify → your site → Deploys →
   click the latest deploy → it shows the full build output). Look
   for a line starting with `[generate-config]`:
   - `SUCCESS — ... written with real Supabase values` → the build
     saw your variables. If the live site still looks unconnected,
     it's a browser cache issue — hard refresh (Ctrl/Cmd+Shift+R).
   - `NOT CONFIGURED — ...` → the build ran, but the variables
     weren't visible to it. Re-check the variable **names** are
     exactly `SUPABASE_URL` and `SUPABASE_ANON_KEY` (no typos, no
     extra spaces), and that they're enabled for the **Production**
     deploy context (Site configuration → Environment variables →
     each variable has a scope setting).
   - **No `[generate-config]` line at all, anywhere in the log** →
     the build command never ran. This happens if the site was
     originally created via Netlify's drag-and-drop upload (which
     publishes files as-is with no build step) rather than "Import
     from Git." Fix: **Site configuration → Build & deploy → Build
     settings** — confirm Build command shows `npm run build` and
     Publish directory shows `.`. If that section is empty or
     missing, the site isn't wired to run a build at all; the fix is
     importing the project from a Git repo (GitHub/GitLab/Bitbucket)
     instead of drag-and-drop, so Netlify has something to build from
     each time.
2. If the log shows `SUCCESS`, also open the deployed
   `js/supabase-config.js` directly in a browser
   (`your-site.netlify.app/js/supabase-config.js`) — it should show
   your real project URL, not `YOUR_SUPABASE_PROJECT_URL`. If it
   still shows the placeholder despite a `SUCCESS` log, that's a caching
   layer serving an old deploy — use Deploys → Trigger deploy → **Clear
   cache and deploy site**, not just "Trigger deploy."

## H) How to test the deployed site

1. Open the Netlify preview URL — every page from the routing list
   should load directly (e.g. `/movies.html`, `/movie.html?id=...`).
2. Confirm the padlock/HTTPS is active (automatic on Netlify).
3. Sign up a test account, log in, favorite a movie, log out, log
   back in — confirm it persisted (Step 4's checklist, now against
   the real deployed URL instead of a local file).
4. Try a Premium movie while logged out/not subscribed → confirm
   "Subscribe to Watch," not the player.
5. Visit a non-existent URL (e.g. `/nope.html`) → confirm the branded
   404 page appears, not a raw hosting-platform error.
6. Open browser dev tools → Network tab → confirm no request ever
   includes a Stripe secret key, webhook secret, or Supabase
   service-role key (search the page source too) — everything sent
   from the browser should only ever be the anon key.
7. Run the site through Google's [Rich Results
   Test](https://search.google.com/test/rich-results) or just view
   page source to confirm title/description/OG tags render with real
   values (once you've swapped in your real domain).
