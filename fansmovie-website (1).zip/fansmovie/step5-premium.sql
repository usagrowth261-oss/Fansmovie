-- =========================================================
-- FansMovie — STEP 5 migration: premium membership & payments
-- Run this in: Supabase Dashboard → SQL Editor → New query
-- (Run this AFTER schema.sql, step2/3/4 migrations)
-- Safe to run once; uses IF NOT EXISTS / OR REPLACE guards.
-- =========================================================

-- 1. SPLIT VIDEO STREAM URL OUT OF `movies` -------------------------
-- Why: the existing `movies` table is readable by anyone (that's how
-- browsing/search works — see schema.sql's public_read_published_movies
-- policy). If video_url stayed in that same row, a non-subscriber could
-- fetch a Premium movie's stream URL directly from the API even with
-- every "Subscribe to Watch" button in the UI — RLS is per-ROW, not
-- per-column, so the only correct fix is to move the sensitive column
-- into its own table with its own access rules.
create table if not exists public.movie_streams (
  movie_id   uuid primary key references public.movies(id) on delete cascade,
  video_url  text,
  updated_at timestamptz not null default now()
);

-- One-time data migration: copy any video_url already set from Steps 2–3
-- into the new table, then remove it from the old (widely-readable) spot.
do $$
begin
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='movies' and column_name='video_url') then
    insert into public.movie_streams (movie_id, video_url)
    select id, video_url from public.movies where video_url is not null and video_url <> ''
    on conflict (movie_id) do update set video_url = excluded.video_url;

    alter table public.movies drop column video_url;
  end if;
end $$;


-- 2. SUBSCRIPTION PLANS -----------------------------------------------
create table if not exists public.subscription_plans (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null,                 -- e.g. "Monthly", "Yearly"
  billing_period     text not null check (billing_period in ('monthly','yearly')),
  price              numeric not null default 0,     -- set your real price after creating the matching Stripe Price
  currency           text not null default 'USD',    -- ISO 4217 code, e.g. USD, INR, EUR — not hard-coded in the app
  description        text,
  provider_price_id  text,                           -- Stripe Price ID (price_...), filled in once you create it in Stripe
  active             boolean not null default true,  -- inactive plans are hidden from premium.html
  created_at         timestamptz not null default now()
);

-- Starter rows so premium.html has something to render. Price is a
-- placeholder (0) until you set a real one — see SETUP.md Step 5.
insert into public.subscription_plans (name, billing_period, price, currency, description)
select 'Monthly', 'monthly', 0, 'USD', 'Full access to Premium titles, billed every month.'
where not exists (select 1 from public.subscription_plans where billing_period = 'monthly');

insert into public.subscription_plans (name, billing_period, price, currency, description)
select 'Yearly', 'yearly', 0, 'USD', 'Full access to Premium titles, billed once a year.'
where not exists (select 1 from public.subscription_plans where billing_period = 'yearly');


-- 3. USER SUBSCRIPTIONS -------------------------------------------------
create table if not exists public.subscriptions (
  id                     uuid primary key default gen_random_uuid(),
  -- References public.profiles (not auth.users directly) so PostgREST can
  -- embed the user's email for the admin dashboard — see profiles table
  -- in step4-users.sql. profiles.id IS auth.users.id, so this behaves
  -- identically; every real user always has a profiles row (auto-created
  -- by the trigger in step4-users.sql).
  user_id                uuid not null references public.profiles(id) on delete cascade,
  plan_id                uuid references public.subscription_plans(id),
  status                 text not null check (status in ('pending','active','cancelled','expired')) default 'pending',
  current_period_start   timestamptz,
  current_period_end     timestamptz,
  payment_provider       text,              -- e.g. 'stripe'
  provider_customer_id   text,              -- Stripe customer ID (cus_...)
  provider_subscription_id text,            -- Stripe subscription ID (sub_...)
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

-- Only one ACTIVE subscription per user at a time (history is kept —
-- old rows just move to 'expired'/'cancelled' instead of being deleted).
create unique index if not exists subscriptions_one_active_per_user
  on public.subscriptions (user_id) where (status = 'active');

create index if not exists subscriptions_user_idx on public.subscriptions(user_id);
create index if not exists subscriptions_provider_sub_idx on public.subscriptions(provider_subscription_id);


-- 4. TRANSACTIONS (payment record) --------------------------------------
create table if not exists public.transactions (
  id                     uuid primary key default gen_random_uuid(),
  user_id                uuid not null references public.profiles(id) on delete cascade,
  subscription_id        uuid references public.subscriptions(id) on delete set null,
  plan_id                uuid references public.subscription_plans(id),
  amount                 numeric,
  currency               text,
  status                 text not null check (status in ('succeeded','failed','pending','refunded')),
  payment_provider       text,              -- e.g. 'stripe', or 'manual_admin_grant' — see part 7
  provider_transaction_id text,             -- Stripe payment_intent/invoice ID, for idempotency & support lookups
  created_at             timestamptz not null default now()
);

create index if not exists transactions_user_idx on public.transactions(user_id);
create unique index if not exists transactions_provider_ref_unique
  on public.transactions(payment_provider, provider_transaction_id)
  where provider_transaction_id is not null; -- prevents a re-delivered webhook from double-recording a payment


-- 5. ROW LEVEL SECURITY ---------------------------------------------------
alter table public.movie_streams     enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.subscriptions      enable row level security;
alter table public.transactions       enable row level security;

-- profiles: let admins read every profile (needed so the admin dashboard
-- can show which email each subscription/transaction belongs to). Regular
-- users still only ever see their own row (profiles_select_own, from
-- step4-users.sql) — this ADDS an admin-only path, it doesn't loosen that.
drop policy if exists "admin_read_all_profiles" on public.profiles;
create policy "admin_read_all_profiles" on public.profiles
for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- movie_streams: this is the actual paywall enforcement.
-- Free, published movies: their stream URL is readable by anyone.
drop policy if exists "free_stream_read" on public.movie_streams;
create policy "free_stream_read" on public.movie_streams
for select to anon, authenticated
using (
  exists (
    select 1 from public.movies m
    where m.id = movie_streams.movie_id and m.published = true and m.tier = 'free'
  )
);

-- Premium, published movies: their stream URL is readable only by a
-- signed-in user with a currently active, unexpired subscription.
-- This is checked here — in the database — not just in the app's UI.
drop policy if exists "premium_stream_read_if_subscribed" on public.movie_streams;
create policy "premium_stream_read_if_subscribed" on public.movie_streams
for select to authenticated
using (
  exists (
    select 1 from public.movies m
    where m.id = movie_streams.movie_id and m.published = true and m.tier = 'premium'
  )
  and exists (
    select 1 from public.subscriptions s
    where s.user_id = auth.uid()
      and s.status = 'active'
      and s.current_period_end > now()
  )
);

-- Admins can read/write every stream URL (this is what the admin panel uses).
drop policy if exists "admin_full_access_movie_streams" on public.movie_streams;
create policy "admin_full_access_movie_streams" on public.movie_streams
for all to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- subscription_plans: anyone can see ACTIVE plans (for premium.html);
-- only admins can manage them.
drop policy if exists "public_read_active_plans" on public.subscription_plans;
create policy "public_read_active_plans" on public.subscription_plans
for select to anon, authenticated
using (active = true);

drop policy if exists "admin_read_all_plans" on public.subscription_plans;
create policy "admin_read_all_plans" on public.subscription_plans
for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "admin_write_plans" on public.subscription_plans;
create policy "admin_write_plans" on public.subscription_plans
for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- subscriptions: a user can read only their own row.
-- IMPORTANT: there is intentionally NO insert/update/delete policy for
-- regular users, and NO general-purpose admin write policy either.
-- The only ways a row here changes are: (a) the stripe-webhook Edge
-- Function, which uses the service-role key and therefore bypasses RLS
-- entirely, or (b) the admin_grant_subscription() function below, which
-- is the one deliberately-controlled exception. This is what stops
-- anyone — including an admin working from the browser — from just
-- flipping a switch to fake a paid subscription.
drop policy if exists "subscriptions_select_own" on public.subscriptions;
create policy "subscriptions_select_own" on public.subscriptions
for select to authenticated using (user_id = auth.uid());

drop policy if exists "admin_read_all_subscriptions" on public.subscriptions;
create policy "admin_read_all_subscriptions" on public.subscriptions
for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- transactions: same shape — read own, admin can read all, nobody can
-- write from the browser at all.
drop policy if exists "transactions_select_own" on public.transactions;
create policy "transactions_select_own" on public.transactions
for select to authenticated using (user_id = auth.uid());

drop policy if exists "admin_read_all_transactions" on public.transactions;
create policy "admin_read_all_transactions" on public.transactions
for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));


-- 6. HELPER: does a user currently have active premium access? ------------
-- Used by the app for UI state; the *real* enforcement is the RLS
-- policy on movie_streams above, not this function.
create or replace function public.has_active_subscription(uid uuid)
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1 from public.subscriptions
    where user_id = uid and status = 'active' and current_period_end > now()
  );
$$;

grant execute on function public.has_active_subscription(uuid) to anon, authenticated;


-- 7. CONTROLLED ADMIN OVERRIDE: manually grant/revoke a subscription -------
-- This is the ONLY way an admin can mark someone as subscribed without a
-- real payment (e.g. a comp account, a support fix, a legally-licensed
-- promo). It is intentionally its own function, not a table UPDATE, so
-- it's auditable and can never be confused with a real Stripe payment —
-- it always records the transaction as payment_provider = 'manual_admin_grant',
-- never as 'stripe' or "succeeded" in a way that looks like a real charge.
create or replace function public.admin_grant_subscription(
  target_user_id uuid,
  target_plan_id uuid,
  period_days integer default 30
)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.admins a where a.user_id = auth.uid()) then
    raise exception 'Only an admin can grant a subscription.';
  end if;

  update public.subscriptions set status = 'expired', updated_at = now()
  where user_id = target_user_id and status = 'active';

  insert into public.subscriptions (user_id, plan_id, status, current_period_start, current_period_end, payment_provider)
  values (target_user_id, target_plan_id, 'active', now(), now() + make_interval(days => period_days), 'manual_admin_grant');

  insert into public.transactions (user_id, plan_id, status, payment_provider, provider_transaction_id, amount, currency)
  values (target_user_id, target_plan_id, 'succeeded', 'manual_admin_grant', 'admin:' || auth.uid()::text || ':' || now()::text, 0, 'N/A');
end;
$$;

grant execute on function public.admin_grant_subscription(uuid, uuid, integer) to authenticated;
-- (the function checks admin membership itself — granting EXECUTE to all
-- authenticated users is safe; a non-admin calling it just gets rejected.)


comment on table public.movie_streams is 'Actual video stream URLs, separated from movies so RLS can gate Premium content per-user. See policies on this table for the real access control.';
comment on table public.subscriptions is 'Written only by the stripe-webhook Edge Function (service role) or admin_grant_subscription(). Never writable directly from the browser.';
comment on table public.transactions is 'Payment history. Written only by the stripe-webhook Edge Function (service role) or admin_grant_subscription(). Never writable directly from the browser.';
