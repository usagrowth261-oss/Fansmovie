-- =========================================================
-- FansMovie — STEP 2 migration: poster storage
-- Run this in: Supabase Dashboard → SQL Editor → New query
-- (Run this AFTER schema.sql from Step 1 has already been run.)
-- Safe to run once; uses IF NOT EXISTS / ON CONFLICT guards.
-- =========================================================

-- 1. Track which storage object backs each movie's poster, so the
--    admin panel can delete/replace the old file when a poster is
--    replaced. The public poster_url column (already created in
--    Step 1) is what the website actually displays.
alter table public.movies
  add column if not exists poster_path text;

comment on column public.movies.poster_path is
  'Path inside the "posters" Storage bucket for this movie''s uploaded poster file, e.g. 1234-my-poster.jpg. Null if poster_url is an external link instead of an uploaded file.';


-- 2. Create the "posters" Storage bucket (public read, so poster
--    images can be shown on the site without a signed URL).
insert into storage.buckets (id, name, public)
values ('posters', 'posters', true)
on conflict (id) do nothing;


-- 3. Storage policies for the "posters" bucket -------------------
-- Anyone (including logged-out visitors) can VIEW poster files —
-- this is required for poster images to render on the public site.
drop policy if exists "public_read_posters" on storage.objects;
create policy "public_read_posters"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'posters');

-- Only whitelisted admins (see public.admins from Step 1) can
-- upload new poster files.
drop policy if exists "admin_upload_posters" on storage.objects;
create policy "admin_upload_posters"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'posters'
  and exists (select 1 from public.admins a where a.user_id = auth.uid())
);

-- Only admins can overwrite/replace a poster file.
drop policy if exists "admin_update_posters" on storage.objects;
create policy "admin_update_posters"
on storage.objects for update
to authenticated
using (
  bucket_id = 'posters'
  and exists (select 1 from public.admins a where a.user_id = auth.uid())
)
with check (
  bucket_id = 'posters'
  and exists (select 1 from public.admins a where a.user_id = auth.uid())
);

-- Only admins can delete a poster file (e.g. when replacing it,
-- or deleting a movie).
drop policy if exists "admin_delete_posters" on storage.objects;
create policy "admin_delete_posters"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'posters'
  and exists (select 1 from public.admins a where a.user_id = auth.uid())
);

-- Note: there is intentionally NO storage bucket for movie video
-- files in this step. Supabase Storage is not a video streaming
-- service (no adaptive bitrate, no transcoding, and large uploads
-- through a browser tab are slow and easy to break). video_url and
-- trailer_url (added in Step 1) remain plain URL columns — see
-- SETUP.md "Step 2 — what's still needed for real video streaming"
-- for which external service to connect and how.
