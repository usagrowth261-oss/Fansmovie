-- =========================================================
-- FansMovie — STEP 4 migration: user accounts & personal data
-- Run this in: Supabase Dashboard → SQL Editor → New query
-- (Run this AFTER schema.sql, step2-storage.sql, step3-video.sql)
-- Safe to run once; uses IF NOT EXISTS / OR REPLACE guards.
-- =========================================================

-- 1. PROFILES ------------------------------------------------------
-- One row per signed-up user, auto-created on sign-up (see trigger
-- below). Holds only what the account page needs to show.
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text not null,
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();


-- 2. FAVORITES -------------------------------------------------------
create table if not exists public.favorites (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  movie_id   uuid not null references public.movies(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, movie_id)
);

-- 3. WATCHLIST ---------------------------------------------------------
create table if not exists public.watchlist (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  movie_id   uuid not null references public.movies(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, movie_id)
);

-- 4. WATCH HISTORY ("Recently Watched") ---------------------------------
-- One row per (user, movie); re-watching just bumps watched_at instead
-- of creating a duplicate row.
create table if not exists public.watch_history (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  movie_id   uuid not null references public.movies(id) on delete cascade,
  watched_at timestamptz not null default now(),
  unique (user_id, movie_id)
);

-- 5. WATCH PROGRESS ("Continue Watching") --------------------------------
-- One row per (user, movie) while in progress. The app deletes the row
-- once a title is finished (see js/user-data.js), so this table only
-- ever holds titles that are genuinely partway through.
create table if not exists public.watch_progress (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references auth.users(id) on delete cascade,
  movie_id         uuid not null references public.movies(id) on delete cascade,
  position_seconds numeric not null default 0,
  duration_seconds numeric,
  updated_at       timestamptz not null default now(),
  unique (user_id, movie_id)
);


-- 6. ROW LEVEL SECURITY ---------------------------------------------------
alter table public.profiles       enable row level security;
alter table public.favorites      enable row level security;
alter table public.watchlist      enable row level security;
alter table public.watch_history  enable row level security;
alter table public.watch_progress enable row level security;

-- profiles: a user may read/update only their own row. No public read —
-- other visitors' emails are never exposed.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
for select to authenticated using (id = auth.uid());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- favorites: full CRUD, but only on rows that belong to the caller.
drop policy if exists "favorites_select_own" on public.favorites;
create policy "favorites_select_own" on public.favorites
for select to authenticated using (user_id = auth.uid());

drop policy if exists "favorites_insert_own" on public.favorites;
create policy "favorites_insert_own" on public.favorites
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "favorites_delete_own" on public.favorites;
create policy "favorites_delete_own" on public.favorites
for delete to authenticated using (user_id = auth.uid());

-- watchlist: same shape as favorites.
drop policy if exists "watchlist_select_own" on public.watchlist;
create policy "watchlist_select_own" on public.watchlist
for select to authenticated using (user_id = auth.uid());

drop policy if exists "watchlist_insert_own" on public.watchlist;
create policy "watchlist_insert_own" on public.watchlist
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "watchlist_delete_own" on public.watchlist;
create policy "watchlist_delete_own" on public.watchlist
for delete to authenticated using (user_id = auth.uid());

-- watch_history: read/insert/update own rows (update is what "bump the
-- timestamp instead of duplicating" uses via upsert). No delete needed.
drop policy if exists "watch_history_select_own" on public.watch_history;
create policy "watch_history_select_own" on public.watch_history
for select to authenticated using (user_id = auth.uid());

drop policy if exists "watch_history_insert_own" on public.watch_history;
create policy "watch_history_insert_own" on public.watch_history
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "watch_history_update_own" on public.watch_history;
create policy "watch_history_update_own" on public.watch_history
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- watch_progress: full CRUD on own rows (delete is used when a title
-- is finished, or when the user removes it manually).
drop policy if exists "watch_progress_select_own" on public.watch_progress;
create policy "watch_progress_select_own" on public.watch_progress
for select to authenticated using (user_id = auth.uid());

drop policy if exists "watch_progress_insert_own" on public.watch_progress;
create policy "watch_progress_insert_own" on public.watch_progress
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "watch_progress_update_own" on public.watch_progress;
create policy "watch_progress_update_own" on public.watch_progress
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "watch_progress_delete_own" on public.watch_progress;
create policy "watch_progress_delete_own" on public.watch_progress
for delete to authenticated using (user_id = auth.uid());

-- Note: none of this touches the `admins` table or the movies table's
-- existing admin-only write policies from schema.sql. A normal signed-up
-- user is never added to `admins`, so they still cannot read unpublished
-- movies or write to the movies table — see SETUP.md "Step 4 — admin
-- separation" for why it's now safe to re-enable public sign-ups.
