/* =========================================================
   FansMovie — centralized ad slot system
   Reads placement config from Supabase (public.ad_slots — see
   step6-ads.sql) so slots can be enabled/disabled and given a
   provider + network code from the admin dashboard, without
   editing page code.

   STATUS: no ad network is connected in this codebase. Every slot
   ships with provider/network_code empty, so every slot renders the
   plain "Advertisement" placeholder below — never a fake ad, never a
   real one either, until you deliberately configure one.
   ========================================================= */

let AD_SLOTS_CACHE = null;

async function loadAdSlotsConfig(){
  if(AD_SLOTS_CACHE) return AD_SLOTS_CACHE;
  if(!SUPABASE_IS_CONFIGURED){ AD_SLOTS_CACHE = {}; return AD_SLOTS_CACHE; }
  const { data, error } = await supabaseClient.from("ad_slots").select("*");
  if(error){ console.error("loadAdSlotsConfig:", error); AD_SLOTS_CACHE = {}; return AD_SLOTS_CACHE; }
  AD_SLOTS_CACHE = {};
  data.forEach(row => { AD_SLOTS_CACHE[row.slot_key] = row; });
  return AD_SLOTS_CACHE;
}

function deviceMatches(device){
  if(device === "both") return true;
  const isMobile = window.matchMedia("(max-width: 760px)").matches;
  return device === "mobile" ? isMobile : !isMobile;
}

/** Fills every element with data-ad-slot="<slot_key>" on the current page. */
async function renderAdSlots(){
  const els = document.querySelectorAll("[data-ad-slot]");
  if(!els.length) return;
  const config = await loadAdSlotsConfig();

  els.forEach(el => {
    const key = el.dataset.adSlot;
    const slot = config[key];

    // Ad-free Premium: only skips the slot if a plan explicitly has
    // ad_free = true AND the viewer holds it — see js/subscriptions.js /
    // js/app.js (FM.adFree). Never assumed by default.
    if(FM.adFree){ el.style.display = "none"; return; }

    if(!slot){ return; } // unknown slot key — leave whatever placeholder markup is already there

    if(!deviceMatches(slot.device)){ el.style.display = "none"; return; }

    if(!slot.enabled || !slot.provider || !slot.network_code){
      // Not configured yet — show the plain, honest placeholder. This is
      // the ONLY state this codebase ships in; nothing fake is ever shown.
      el.style.display = "";
      el.innerHTML = `<span>Advertisement</span>`;
      return;
    }

    // A real network IS configured (this only happens once an admin has
    // deliberately filled in provider + network_code for this slot).
    el.style.display = "";
    if(slot.provider === "google_adsense"){
      renderGoogleAdSenseSlot(el, slot.network_code);
    } else {
      el.innerHTML = `<span>Advertisement</span>`; // unrecognized provider — fail safe to the honest placeholder
    }
  });
}

/* ---------------- Admin management ----------------
   Relies on admin_write_ad_slots RLS policy (step6-ads.sql). A
   non-admin caller's update will simply fail via RLS. */

async function fetchAllAdSlotsAdmin(){
  const { data, error } = await supabaseClient.from("ad_slots").select("*").order("slot_key");
  if(error){ console.error("fetchAllAdSlotsAdmin:", error); return []; }
  return data || [];
}

async function updateAdSlotAdmin(slotKey, fields){
  const { error } = await supabaseClient.from("ad_slots").update(fields).eq("slot_key", slotKey);
  if(error) return { ok:false, message: error.message };
  AD_SLOTS_CACHE = null; // invalidate cache so the next page load picks up the change
  return { ok:true };
}
/** Loads the official AdSense async script once, then inserts the standard <ins> ad unit. */
function renderGoogleAdSenseSlot(el, adClientId){
  if(!window.__adsenseScriptLoading){
    window.__adsenseScriptLoading = true;
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" + encodeURIComponent(adClientId);
    script.crossOrigin = "anonymous";
    document.head.appendChild(script);
  }
  el.innerHTML = `<ins class="adsbygoogle" style="display:block;width:100%;height:100%" data-ad-client="${adClientId}" data-ad-format="auto" data-full-width-responsive="true"></ins>`;
  window.adsbygoogle = window.adsbygoogle || [];
  try{ window.adsbygoogle.push({}); } catch(e){ console.error("AdSense push failed:", e); }
}
