/* =========================================================
   FansMovie — Supabase connection config
   ---------------------------------------------------------
   Fill these two values in from your own Supabase project:
   Supabase Dashboard → Settings → API
     - "Project URL"        → SUPABASE_URL
     - "anon public" key    → SUPABASE_ANON_KEY

   The anon key is safe to expose in front-end code — it can
   only do what your Row Level Security policies allow it to
   do (see schema.sql). Never put a "service_role" key here.

   Until both values below are replaced, the site runs in
   "not connected" mode: the public pages fall back to the
   sample placeholder catalog, and the admin dashboard shows
   a setup screen instead of pretending to be connected.
   ========================================================= */

const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL"; // e.g. https://xxxxxxxx.supabase.co
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";

const SUPABASE_IS_CONFIGURED =
  SUPABASE_URL.startsWith("http") &&
  SUPABASE_ANON_KEY &&
  SUPABASE_ANON_KEY !== "YOUR_SUPABASE_ANON_PUBLIC_KEY";

const supabaseClient = SUPABASE_IS_CONFIGURED
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

if (!SUPABASE_IS_CONFIGURED) {
  console.warn("[FansMovie] Supabase is not configured yet — edit js/supabase-config.js with your project URL and anon key.");
}
