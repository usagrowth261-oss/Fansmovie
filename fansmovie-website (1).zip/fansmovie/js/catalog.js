/* =========================================================
   FansMovie — catalog loader
   Used by index.html, movies.html, movie.html, favorites.html
   so all public pages get their movies the same way: try the
   real Supabase database first, fall back to the built-in
   sample data (js/data.js) if it isn't connected yet or the
   request fails — and always say plainly which one is showing.
   ========================================================= */

let CATALOG_SOURCE = "sample"; // "database" once a real fetch succeeds

/** Home-page rows (Featured/Trending/Popular/Recently Added) are static
    flags in the sample data. Real DB rows don't have those flags, so
    derive reasonable equivalents from rating and recency instead. */
function deriveHomeFlags(list){
  const byRating = [...list].sort((a,b) => (b.rating||0)-(a.rating||0));
  const byRecency = [...list].sort((a,b) => new Date(b.createdAt||0) - new Date(a.createdAt||0));
  const topRated = new Set(byRating.slice(0,10).map(m=>m.id));
  const mostRecent = new Set(byRecency.slice(0,10).map(m=>m.id));
  return list.map(m => ({
    ...m,
    featured: topRated.has(m.id),
    trending: mostRecent.has(m.id),
    popular: topRated.has(m.id),
    latest: mostRecent.has(m.id),
    recent: mostRecent.has(m.id),
  }));
}

/** Returns an array of movies in the shared card shape, from whichever
    source is actually available right now. Never throws — a database
    or network outage falls back to the sample catalog with an honest
    on-page notice (see renderDataSourceNotice) instead of leaving the
    page blank or broken. */
async function loadCatalog(){
  try{
    if(typeof SUPABASE_IS_CONFIGURED !== "undefined" && SUPABASE_IS_CONFIGURED){
      const dbMovies = await fetchPublishedMovies();
      if(dbMovies && dbMovies.length){
        CATALOG_SOURCE = "database";
        return deriveHomeFlags(dbMovies);
      }
    }
  } catch(err){
    console.error("loadCatalog: falling back to sample data after an unexpected error:", err);
  }
  CATALOG_SOURCE = "sample";
  return MOVIES;
}

/** Shows/hides the small on-page notice explaining which data is showing.
    Call after loadCatalog() resolves, once #dataSourceNotice exists. */
function renderDataSourceNotice(){
  const el = document.getElementById("dataSourceNotice");
  if(!el) return;
  if(CATALOG_SOURCE === "database"){
    el.style.display = "none";
    return;
  }
  el.style.display = "block";
  el.innerHTML = (typeof SUPABASE_IS_CONFIGURED !== "undefined" && SUPABASE_IS_CONFIGURED)
    ? "<strong>Note:</strong> couldn't load movies from the database right now — showing sample placeholder data instead."
    : "<strong>Note:</strong> Supabase isn't connected yet — showing sample placeholder data. See <code>SETUP.md</code>.";
}
