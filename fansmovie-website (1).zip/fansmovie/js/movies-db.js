/* =========================================================
   FansMovie — Supabase data layer
   All real database + auth calls live here so the page files
   stay simple. Requires js/supabase-config.js to be filled in
   and schema.sql to have been run in your Supabase project.
   ========================================================= */

/* Map a `movies` table row to the shape the existing card/UI
   rendering code (app.js) already expects, so the front-end
   design never has to change. */
function mapDbMovie(row){
  const streamRow = Array.isArray(row.movie_streams) ? row.movie_streams[0] : row.movie_streams;
  return {
    id: row.id,
    title: row.title,
    year: row.year,
    language: row.language,
    genre: row.genre,
    category: row.category,
    duration: row.duration,
    rating: row.rating,
    tier: row.tier,
    sponsored: !!row.sponsored,
    desc: row.description,
    published: row.published,
    createdAt: row.created_at,
    poster: row.poster_url && row.poster_url.trim() ? row.poster_url : posterDataUrl(row.title || "Untitled", row.genre || "Drama"),
    posterPath: row.poster_path || null,
    trailerUrl: row.trailer_url,
    // NOTE: this is only ever populated for the admin fetch below (which
    // embeds movie_streams and is gated by the admin RLS policy on that
    // table). Public reads never see a real video URL here — see
    // js/subscriptions.js: fetchStreamUrl(), which is the RLS-gated path
    // actual playback uses.
    videoUrl: streamRow ? streamRow.video_url : null,
  };
}

/* ---------------- Public catalog reads ---------------- */

/** Published movies only — used by index.html, movies.html, movie.html, favorites.html */
async function fetchPublishedMovies(){
  if(!SUPABASE_IS_CONFIGURED) return null; // caller decides how to fall back
  const { data, error } = await supabaseClient
    .from("movies")
    .select("*")
    .eq("published", true)
    .order("created_at", { ascending: false });
  if(error){ console.error("fetchPublishedMovies error:", error); return null; }
  return data.map(mapDbMovie);
}

async function fetchPublishedMovieById(id){
  if(!SUPABASE_IS_CONFIGURED) return null;
  const { data, error } = await supabaseClient
    .from("movies")
    .select("*")
    .eq("published", true)
    .eq("id", id)
    .maybeSingle();
  if(error){ console.error("fetchPublishedMovieById error:", error); return null; }
  return data ? mapDbMovie(data) : null;
}

/** One published movie flagged Sponsored, if any — used by premium.html's sponsored-placement slot. */
async function fetchSponsoredMovie(){
  if(!SUPABASE_IS_CONFIGURED) return null;
  const { data, error } = await supabaseClient
    .from("movies")
    .select("*")
    .eq("published", true)
    .eq("sponsored", true)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if(error){ console.error("fetchSponsoredMovie error:", error); return null; }
  return data ? mapDbMovie(data) : null;
}

/* ---------------- Poster storage (Supabase Storage) ----------------
   Requires step2-storage.sql to have been run (creates the "posters"
   bucket + its policies). Only an authenticated admin can succeed
   here — the bucket's RLS policies enforce that server-side, this
   is just the client call. */

const POSTER_BUCKET = "posters";

function sanitizeFileName(name){
  return name.toLowerCase().replace(/[^a-z0-9.]+/g, "-").replace(/-+/g, "-");
}

/** Uploads a poster image file, returns { ok, url, path } or { ok:false, message }. */
async function uploadPosterImage(file){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message: "Supabase is not configured." };
  const path = `${Date.now()}-${sanitizeFileName(file.name)}`;
  const { error: uploadError } = await supabaseClient
    .storage.from(POSTER_BUCKET)
    .upload(path, file, { upsert: false, cacheControl: "3600" });
  if(uploadError) return { ok:false, message: uploadError.message };

  const { data } = supabaseClient.storage.from(POSTER_BUCKET).getPublicUrl(path);
  return { ok:true, url: data.publicUrl, path };
}

/** Best-effort delete of a previously uploaded poster file (e.g. when replaced). */
async function deletePosterImage(path){
  if(!path || !SUPABASE_IS_CONFIGURED) return { ok:false };
  const { error } = await supabaseClient.storage.from(POSTER_BUCKET).remove([path]);
  if(error) return { ok:false, message: error.message };
  return { ok:true };
}

/* ---------------- Admin auth ---------------- */

async function adminSignIn(email, password){
  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
  if(error) return { ok:false, message: error.message };
  const isAdmin = await isCurrentUserAdmin();
  if(!isAdmin){
    await supabaseClient.auth.signOut();
    return { ok:false, message: "This account is not registered as a FansMovie admin." };
  }
  return { ok:true, session: data.session };
}

async function adminSignOut(){
  await supabaseClient.auth.signOut();
}

async function getAdminSession(){
  const { data } = await supabaseClient.auth.getSession();
  return data.session || null;
}

async function isCurrentUserAdmin(){
  const { data: userData } = await supabaseClient.auth.getUser();
  const user = userData && userData.user;
  if(!user) return false;
  const { data, error } = await supabaseClient
    .from("admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();
  if(error){ console.error("isCurrentUserAdmin error:", error); return false; }
  return !!data;
}

/* ---------------- Admin catalog reads/writes ----------------
   These rely on RLS policies that only allow rows in `admins`
   to select ALL movies (published or not) and to write. See
   schema.sql. If the signed-in user isn't in `admins`, these
   calls will simply return no rows / a permission error. */

async function fetchAllMoviesAdmin(){
  const { data, error } = await supabaseClient
    .from("movies")
    .select("*, movie_streams(video_url)")
    .order("created_at", { ascending: false });
  if(error){ console.error("fetchAllMoviesAdmin error:", error); return { ok:false, message:error.message }; }
  return { ok:true, movies: data.map(mapDbMovie) };
}

/** Writes (or clears) a movie's stream URL in the separate movie_streams
    table — see step5-premium.sql for why video_url isn't a plain column
    on `movies` anymore (RLS can't gate Premium access per-column). */
async function setMovieStreamUrl(movieId, videoUrl){
  if(videoUrl && videoUrl.trim()){
    const { error } = await supabaseClient
      .from("movie_streams")
      .upsert({ movie_id: movieId, video_url: videoUrl.trim(), updated_at: new Date().toISOString() }, { onConflict: "movie_id" });
    if(error) return { ok:false, message: error.message };
  } else {
    const { error } = await supabaseClient.from("movie_streams").delete().eq("movie_id", movieId);
    if(error) return { ok:false, message: error.message };
  }
  return { ok:true };
}

async function insertMovie(fields){
  const { video_url, ...movieFields } = fields;
  const { data, error } = await supabaseClient.from("movies").insert([movieFields]).select().maybeSingle();
  if(error) return { ok:false, message:error.message };
  if(video_url && video_url.trim()){
    const streamResult = await setMovieStreamUrl(data.id, video_url);
    if(!streamResult.ok) return { ok:false, message: "Movie saved, but the video URL failed to save: " + streamResult.message };
  }
  return { ok:true, movie: mapDbMovie({ ...data, movie_streams: video_url ? { video_url } : null }) };
}

async function updateMovie(id, fields){
  const { video_url, ...movieFields } = fields;
  const { data, error } = await supabaseClient.from("movies").update(movieFields).eq("id", id).select().maybeSingle();
  if(error) return { ok:false, message:error.message };
  if(video_url !== undefined){
    const streamResult = await setMovieStreamUrl(id, video_url);
    if(!streamResult.ok) return { ok:false, message: "Movie updated, but the video URL failed to save: " + streamResult.message };
  }
  return { ok:true, movie: mapDbMovie({ ...data, movie_streams: video_url ? { video_url } : null }) };
}

async function deleteMovie(id, posterPath){
  const { error } = await supabaseClient.from("movies").delete().eq("id", id);
  if(error) return { ok:false, message:error.message };
  if(posterPath) await deletePosterImage(posterPath); // best-effort, ignore failure
  // movie_streams row is removed automatically (on delete cascade, see step5-premium.sql)
  return { ok:true };
}

async function setPublished(id, published){
  return updateMovie(id, { published });
}
