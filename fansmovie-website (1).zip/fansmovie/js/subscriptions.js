/* =========================================================
   FansMovie — subscription plans, status, and checkout
   Real reads/writes against Supabase. The actual "is this user
   allowed to watch this Premium movie" check happens in the
   database (RLS on movie_streams, see step5-premium.sql) — the
   functions here are for displaying correct UI state, not for
   enforcing access by themselves.
   ========================================================= */

async function fetchActivePlans(){
  if(!SUPABASE_IS_CONFIGURED) return [];
  const { data, error } = await supabaseClient
    .from("subscription_plans")
    .select("*")
    .eq("active", true)
    .order("price", { ascending: true });
  if(error){ console.error("fetchActivePlans:", error); return []; }
  return data || [];
}

/** The signed-in user's current subscription row, if any (most recent first). */
async function fetchMySubscription(){
  if(!SUPABASE_IS_CONFIGURED || !FM.user) return null;
  const { data, error } = await supabaseClient
    .from("subscriptions")
    .select("*, subscription_plans(name, billing_period, price, currency, ad_free)")
    .eq("user_id", FM.user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if(error){ console.error("fetchMySubscription:", error); return null; }
  return data;
}

function isSubscriptionActive(sub){
  return !!sub && sub.status === "active" && sub.current_period_end && new Date(sub.current_period_end) > new Date();
}

/** Recent payment history for the signed-in user (for the account page). */
async function fetchMyTransactions(limit = 10){
  if(!SUPABASE_IS_CONFIGURED || !FM.user) return [];
  const { data, error } = await supabaseClient
    .from("transactions")
    .select("*")
    .eq("user_id", FM.user.id)
    .order("created_at", { ascending: false })
    .limit(limit);
  if(error){ console.error("fetchMyTransactions:", error); return []; }
  return data || [];
}

/**
 * Fetches the actual playable stream URL for a movie, if the current
 * viewer is allowed to have it. Returns null if: the movie isn't
 * published, has no stream URL set, or (for Premium titles) the
 * viewer doesn't have an active subscription — all enforced by RLS,
 * not by this function.
 */
async function fetchStreamUrl(movieId){
  if(!SUPABASE_IS_CONFIGURED) return null;
  const { data, error } = await supabaseClient
    .from("movie_streams")
    .select("video_url")
    .eq("movie_id", movieId)
    .maybeSingle();
  if(error){ console.error("fetchStreamUrl:", error); return null; }
  return data ? data.video_url : null;
}

/* ---------------- Admin overview ----------------
   Relies on the admin_read_all_subscriptions / admin_read_all_transactions
   / admin_read_all_profiles RLS policies from step5-premium.sql. Returns
   empty/zero results (not an error) for a non-admin caller, since RLS
   just filters rows rather than raising. */

async function fetchAdminSubscriptionStats(){
  const [{ count: activeCount }, { count: expiredCount }] = await Promise.all([
    supabaseClient.from("subscriptions").select("id", { count: "exact", head: true }).eq("status", "active"),
    supabaseClient.from("subscriptions").select("id", { count: "exact", head: true }).in("status", ["expired", "cancelled"]),
  ]);
  return { active: activeCount || 0, expired: expiredCount || 0 };
}

async function fetchAdminRecentTransactions(limit = 20){
  const { data, error } = await supabaseClient
    .from("transactions")
    .select("*, profiles(email), subscription_plans(name)")
    .order("created_at", { ascending: false })
    .limit(limit);
  if(error){ console.error("fetchAdminRecentTransactions:", error); return []; }
  return data || [];
}

async function fetchAllPlansAdmin(){
  const { data, error } = await supabaseClient.from("subscription_plans").select("*").order("billing_period");
  if(error){ console.error("fetchAllPlansAdmin:", error); return []; }
  return data || [];
}

async function updatePlanAdmin(planId, fields){
  const { error } = await supabaseClient.from("subscription_plans").update(fields).eq("id", planId);
  if(error) return { ok:false, message: error.message };
  return { ok:true };
}
/**
 * Starts a Stripe Checkout for the given plan by calling the
 * create-checkout-session Edge Function. Returns { ok:true, url } on
 * success. If the Edge Function isn't deployed/configured yet, this
 * fails honestly instead of faking a checkout — see the caller in
 * premium.html for how that's surfaced.
 */
async function startCheckout(planId){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message:"Supabase is not configured." };
  if(!FM.user) return { ok:false, message:"Log in first." };
  try{
    const { data, error } = await supabaseClient.functions.invoke("create-checkout-session", {
      body: { planId },
    });
    if(error) return { ok:false, message: error.message || "Checkout isn't connected yet." };
    if(!data || !data.url) return { ok:false, message: (data && data.error) || "Checkout isn't connected yet." };
    return { ok:true, url: data.url };
  } catch(err){
    return { ok:false, message: "Checkout isn't connected yet — the payment backend isn't deployed. See SETUP.md." };
  }
}
