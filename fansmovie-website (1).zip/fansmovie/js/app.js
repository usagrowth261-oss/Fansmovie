/* =========================================================
   FansMovie — shared app logic (header, footer, cards, state)
   FM.user / favorites / watchlist / recentlyWatched / continueWatching
   are a CACHE of the signed-in user's own rows in Supabase (see
   js/user-data.js: syncUserState, toggleFavorite, toggleWatchlist,
   recordWatched, saveProgress). They are populated from the database
   on every page load and every mutation writes through to it — if
   nobody is signed in, or Supabase isn't configured, they simply
   stay empty rather than faking local-only storage.
   ========================================================= */

const FM = {
  user: null,                // Supabase auth user object, or null when signed out
  favorites: new Set(),
  watchlist: new Set(),
  recentlyWatched: [],       // array of movie ids, most recent first
  continueWatching: {},      // { movieId: { position, duration } }
  adFree: false,             // true only if the signed-in user's ACTIVE plan has ad_free = true — never assumed, see js/ads.js
};

/* ---------------- Header / Footer templates ---------------- */

function renderHeader(active){
  const nav = [
    ["index.html", "Home", "home"],
    ["movies.html", "Movies", "movies"],
    ["movies.html?category=bollywood", "Bollywood", "bollywood"],
    ["movies.html?category=hollywood", "Hollywood", "hollywood"],
    ["movies.html?category=south", "South Indian", "south"],
    ["movies.html?category=webseries", "Web Series", "webseries"],
  ];
  const navHtml = nav.map(([href,label,key]) =>
    `<a href="${href}" class="${active===key?'active':''}">${label}</a>`).join("");

  const drawerNav = nav.map(([href,label]) => `<a href="${href}">${label}</a>`).join("")
    + `<a href="favorites.html">My List</a><a href="account.html">Account</a><a href="premium.html">Premium</a><a href="contact.html">Contact</a>`;

  return `
  <header class="site-header">
    <div class="wrap header-inner">
      <a href="index.html" class="logo"><span class="fans">Fans</span><span class="movie">Movie</span></a>
      <nav class="main-nav" aria-label="Primary">${navHtml}</nav>
      <div class="header-actions">
        <button class="icon-btn" id="searchToggle" aria-label="Search" title="Search">${ICON.search}</button>
        <a class="icon-btn" href="favorites.html" aria-label="My List" title="My List">${ICON.bookmark}</a>
        <button class="login-btn" id="loginBtn">Login</button>
        <button class="menu-toggle" id="menuToggle" aria-label="Open menu">${ICON.menu}</button>
      </div>
    </div>
    <div class="search-panel" id="searchPanel">
      <form class="wrap" id="searchForm" role="search">
        <input type="search" id="searchInput" placeholder="Search movies, web series..." aria-label="Search movies">
        <button type="submit">Search</button>
      </form>
    </div>
  </header>
  <div class="drawer" id="drawer">
    <div class="drawer-backdrop" id="drawerBackdrop"></div>
    <div class="drawer-panel">
      <button class="drawer-close" id="drawerClose" aria-label="Close menu">&times;</button>
      <div style="clear:both"></div>
      ${drawerNav}
    </div>
  </div>
  `;
}

function renderFooter(){
  return `
  <footer class="site-footer">
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <h4>FansMovie</h4>
          <a href="about.html">About FansMovie</a>
          <a href="premium.html">Premium</a>
          <a href="contact.html">Contact Us</a>
        </div>
        <div>
          <h4>Browse</h4>
          <a href="movies.html?category=bollywood">Bollywood</a>
          <a href="movies.html?category=hollywood">Hollywood</a>
          <a href="movies.html?category=south">South Indian</a>
          <a href="movies.html?category=webseries">Web Series</a>
        </div>
        <div>
          <h4>Legal</h4>
          <a href="legal.html#privacy">Privacy Policy</a>
          <a href="legal.html#terms">Terms of Use</a>
          <a href="legal.html#refunds">Refund &amp; Cancellation</a>
          <a href="legal.html#dmca">DMCA / Copyright Notice</a>
          <a href="legal.html#disclaimer">Disclaimer</a>
        </div>
        <div>
          <h4>Sponsors</h4>
          <div class="ad-slot" data-ad-slot="footer" style="min-height:70px;"><span>Advertisement</span></div>
        </div>
      </div>
      <div class="footer-legal">
        <p><strong>Copyright &copy; ${new Date().getFullYear()} FansMovie.</strong> All rights reserved.</p>
        <p>FansMovie is intended to host and stream only content that the site owner has produced, licensed, or otherwise
        has explicit legal rights to distribute. This prototype does not include, link to, or facilitate access to
        pirated, torrented, or otherwise unauthorized content. See our <a href="legal.html#dmca">DMCA / Copyright Notice</a>
        for takedown requests and our <a href="legal.html#disclaimer">Disclaimer</a> for full terms.</p>
      </div>
    </div>
  </footer>
  `;
}

const ICON = {
  search: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.6" y2="16.6"/></svg>`,
  bookmark: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 3h12v18l-6-4-6 4V3z"/></svg>`,
  menu: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
  heart: `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.9-10-9.2C.4 8.6 2 5 5.5 5c2 0 3.4 1.1 4.5 2.6C11.1 6.1 12.5 5 14.5 5 18 5 19.6 8.6 22 11.8 19.5 16.1 12 21 12 21z"/></svg>`,
  heartOutline: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7.5-4.9-10-9.2C.4 8.6 2 5 5.5 5c2 0 3.4 1.1 4.5 2.6C11.1 6.1 12.5 5 14.5 5 18 5 19.6 8.6 22 11.8 19.5 16.1 12 21 12 21z"/></svg>`,
};

/* ---------------- Production error safety net ----------------
   Catches anything unexpected so a bug never shows a raw stack
   trace, error message, or blank broken page to a visitor. Always
   logs to the console for debugging — never displays internal
   details in the UI. Every deliberate error path elsewhere in this
   app (login, checkout, favorites, etc.) already shows its own
   specific, safe message; this is only the last-resort catch-all. */
window.addEventListener("error", (e) => {
  console.error("[FansMovie] Unhandled error:", e.error || e.message);
});
window.addEventListener("unhandledrejection", (e) => {
  console.error("[FansMovie] Unhandled promise rejection:", e.reason);
});

/* ---------------- Consent banner ---------------- */
function initConsentBanner(){
  if(document.getElementById("fmConsent")) return;
  try{ if(localStorage.getItem("fm_consent_ack")) return; } catch(e){ /* private browsing etc — just show it each time */ }

  const el = document.createElement("div");
  el.id = "fmConsent";
  el.className = "consent-banner";
  el.innerHTML = `
    <p>FansMovie uses basic cookies/local storage to keep you signed in. If advertising or analytics services are
    connected in the future, this notice will be updated to reflect that. See our
    <a href="legal.html#privacy">Privacy Policy</a>.</p>
    <button class="btn btn-gold" id="fmConsentAck">Got it</button>
  `;
  document.body.appendChild(el);
  document.getElementById("fmConsentAck").addEventListener("click", () => {
    try{ localStorage.setItem("fm_consent_ack", "1"); } catch(e){}
    el.remove();
  });
}

/* ---------------- SEO head tags (favicon, canonical, og:url) ----------------
   Runs on every page via mountLayout so these don't need to be hand-added
   to every HTML file. Canonical/og:url always reflect the real deployed
   URL (origin is only known at runtime) rather than a placeholder that
   could accidentally ship unsubstituted. */
function injectHeadExtras(){
  if(!document.querySelector('link[rel="icon"]')){
    const favicon = document.createElement("link");
    favicon.rel = "icon";
    // Simple inline "F" mark in the brand gold — no separate image asset needed.
    favicon.href = 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="%23121319"/><text x="16" y="23" font-family="Georgia,serif" font-size="20" font-weight="700" fill="%23e6a339" text-anchor="middle">F</text></svg>'
    );
    document.head.appendChild(favicon);
  }

  // Movie pages keep their ?id= query — that's the real canonical identity
  // for that page. Everywhere else, canonical is the clean path.
  const canonicalUrl = window.location.origin + window.location.pathname +
    (window.location.pathname.endsWith("movie.html") ? window.location.search : "");

  let canonical = document.querySelector('link[rel="canonical"]');
  if(!canonical){
    canonical = document.createElement("link");
    canonical.rel = "canonical";
    document.head.appendChild(canonical);
  }
  canonical.href = canonicalUrl;

  let ogUrl = document.querySelector('meta[property="og:url"]');
  if(!ogUrl){
    ogUrl = document.createElement("meta");
    ogUrl.setAttribute("property", "og:url");
    document.head.appendChild(ogUrl);
  }
  ogUrl.setAttribute("content", canonicalUrl);

  if(!document.querySelector('meta[property="og:type"]')){
    const ogType = document.createElement("meta");
    ogType.setAttribute("property", "og:type");
    ogType.setAttribute("content", "website");
    document.head.appendChild(ogType);
  }
}

/* ---------------- Header interactivity ---------------- */

function mountLayout(active){
  document.getElementById("site-header").innerHTML = renderHeader(active);
  document.getElementById("site-footer").innerHTML = renderFooter();
  initConsentBanner();
  injectHeadExtras();

  const searchToggle = document.getElementById("searchToggle");
  const searchPanel = document.getElementById("searchPanel");
  searchToggle.addEventListener("click", () => {
    searchPanel.classList.toggle("open");
    if(searchPanel.classList.contains("open")) document.getElementById("searchInput").focus();
  });
  document.getElementById("searchForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = document.getElementById("searchInput").value.trim();
    window.location.href = "movies.html" + (q ? ("?q=" + encodeURIComponent(q)) : "");
  });

  const menuToggle = document.getElementById("menuToggle");
  const drawer = document.getElementById("drawer");
  menuToggle.addEventListener("click", () => drawer.classList.add("open"));
  document.getElementById("drawerClose").addEventListener("click", () => drawer.classList.remove("open"));
  document.getElementById("drawerBackdrop").addEventListener("click", () => drawer.classList.remove("open"));

  document.getElementById("loginBtn").addEventListener("click", () => {
    window.location.href = "account.html";
  });

  window.authReady = initAuthUI(); // async — pages await this before rendering favorite/watchlist state
}

/** Checks the Supabase session, updates the header's Login/Account label, and refreshes the FM cache. */
async function initAuthUI(){
  if(typeof SUPABASE_IS_CONFIGURED === "undefined" || !SUPABASE_IS_CONFIGURED) return;
  if(typeof getCurrentUser !== "function") return; // user-data.js not loaded on this page
  FM.user = await getCurrentUser();
  await syncUserState();

  // Ad-free Premium is opt-in per plan (see js/subscriptions.js), never assumed.
  if(FM.user && typeof fetchMySubscription === "function"){
    const sub = await fetchMySubscription();
    FM.adFree = !!(isSubscriptionActive(sub) && sub.subscription_plans && sub.subscription_plans.ad_free === true);
  } else {
    FM.adFree = false;
  }

  const loginBtn = document.getElementById("loginBtn");
  if(loginBtn) loginBtn.textContent = FM.user ? "Account" : "Login";

  if(typeof renderAdSlots === "function") renderAdSlots();
}

/* ---------------- Movie card ---------------- */

function movieCard(m, opts){
  opts = opts || {};
  const isFav = FM.favorites.has(String(m.id));
  return `
  <div class="movie-card" data-id="${m.id}">
    <div class="poster" style="padding:0;">
      <img src="${m.poster}" alt="${m.title} poster" loading="lazy" onerror="this.onerror=null;this.src=FALLBACK_POSTER;" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;">
      ${m.tier === "premium" ? `<span class="premium-badge">PREMIUM</span>` : `<span class="badge">FREE</span>`}
      ${m.sponsored ? `<span class="badge" style="top:auto;bottom:34px;left:8px;background:rgba(0,0,0,.65);">SPONSORED</span>` : ``}
      <button class="fav-btn ${isFav?'active':''}" data-fav="${m.id}" aria-label="Toggle favorite" title="Add to favorites">${isFav ? ICON.heart : ICON.heartOutline}</button>
      <span style="position:relative;z-index:1;">${m.title}</span>
    </div>
    ${typeof opts.progressPct === "number" ? `<div class="progress-track"><div class="progress-fill" style="width:${opts.progressPct}%"></div></div>` : ``}
    <div class="card-body">
      <div class="card-meta">
        <span>${m.year}</span><span>${m.language}</span><span>${m.genre}</span>
      </div>
      <a class="watch-btn" href="movie.html?id=${m.id}">Watch Now</a>
    </div>
  </div>`;
}

function movieRow(list){ return list.map(movieCard).join(""); }

function attachFavHandlers(container){
  container.querySelectorAll("[data-fav]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      const id = btn.dataset.fav;

      if(typeof SUPABASE_IS_CONFIGURED === "undefined" || !SUPABASE_IS_CONFIGURED){
        toast("Favorites need Supabase connected first — see SETUP.md.");
        return;
      }
      if(typeof CATALOG_SOURCE !== "undefined" && CATALOG_SOURCE !== "database"){
        toast("This is sample placeholder data — favorites only work on real published movies.");
        return;
      }
      if(!FM.user){
        toast("Log in to save favorites — tap Account in the top menu.");
        return;
      }

      const willBeActive = !FM.favorites.has(id);
      btn.classList.toggle("active", willBeActive);
      btn.innerHTML = willBeActive ? ICON.heart : ICON.heartOutline; // optimistic UI
      const result = await toggleFavorite(id);
      if(!result.ok){
        btn.classList.toggle("active", !willBeActive);
        btn.innerHTML = !willBeActive ? ICON.heart : ICON.heartOutline; // revert on failure
        console.error("toggleFavorite failed:", result.message);
        toast("Couldn't update favorites right now — please try again.");
        return;
      }
      toast(result.active ? "Added to favorites" : "Removed from favorites");
    });
  });
}

/* ---------------- Toast ---------------- */
let toastTimer;
function toast(msg){
  let el = document.getElementById("fmToast");
  if(!el){
    el = document.createElement("div");
    el.id = "fmToast";
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------------- Search helper (used by movies.html) ---------------- */
function searchMovies(list, query){
  const q = query.trim().toLowerCase();
  if(!q) return list;
  return list.filter(m => m.title.toLowerCase().includes(q));
}
