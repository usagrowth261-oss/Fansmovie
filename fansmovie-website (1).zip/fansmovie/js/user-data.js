/* =========================================================
   FansMovie — user accounts & personal data (Supabase)
   Handles: sign up / login / logout / password reset, and
   Favorites / Watchlist / Recently Watched / Continue Watching,
   all backed by real Supabase tables (see step4-users.sql).

   FM.user / FM.favorites / FM.watchlist / FM.recentlyWatched /
   FM.continueWatching (declared in app.js) are a CACHE of the
   signed-in user's own DB rows, refreshed from Supabase on load
   via syncUserState(). They are never used as a substitute for
   real storage — if nobody is signed in, they simply stay empty.
   ========================================================= */

/* ---------------- Auth ---------------- */

async function getCurrentUser(){
  if(typeof SUPABASE_IS_CONFIGURED === "undefined" || !SUPABASE_IS_CONFIGURED) return null;
  const { data, error } = await supabaseClient.auth.getUser();
  if(error) return null;
  return (data && data.user) ? data.user : null;
}

async function signUpUser(email, password){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message:"Supabase is not configured." };
  const { data, error } = await supabaseClient.auth.signUp({ email, password });
  if(error) return { ok:false, message: error.message };
  const needsConfirmation = !data.session;
  return { ok:true, needsConfirmation };
}

async function signInUser(email, password){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message:"Supabase is not configured." };
  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
  if(error) return { ok:false, message: error.message };
  return { ok:true, session: data.session };
}

async function signOutUser(){
  if(!SUPABASE_IS_CONFIGURED) return;
  await supabaseClient.auth.signOut();
}

async function sendPasswordReset(email){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message:"Supabase is not configured." };
  const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + window.location.pathname.replace(/[^/]*$/, "") + "account.html",
  });
  if(error) return { ok:false, message: error.message };
  return { ok:true };
}

async function setNewPassword(newPassword){
  if(!SUPABASE_IS_CONFIGURED) return { ok:false, message:"Supabase is not configured." };
  const { error } = await supabaseClient.auth.updateUser({ password: newPassword });
  if(error) return { ok:false, message: error.message };
  return { ok:true };
}

/* ---------------- Load the signed-in user's own data into FM cache ---------------- */

async function syncUserState(){
  FM.favorites = new Set();
  FM.watchlist = new Set();
  FM.recentlyWatched = [];
  FM.continueWatching = {};
  if(!FM.user) return;

  const [favs, wl, hist, prog] = await Promise.all([
    supabaseClient.from("favorites").select("movie_id").eq("user_id", FM.user.id),
    supabaseClient.from("watchlist").select("movie_id").eq("user_id", FM.user.id),
    supabaseClient.from("watch_history").select("movie_id, watched_at").eq("user_id", FM.user.id).order("watched_at", { ascending:false }).limit(30),
    supabaseClient.from("watch_progress").select("movie_id, position_seconds, duration_seconds").eq("user_id", FM.user.id),
  ]);

  if(favs.data) favs.data.forEach(r => FM.favorites.add(r.movie_id));
  if(wl.data) wl.data.forEach(r => FM.watchlist.add(r.movie_id));
  if(hist.data) FM.recentlyWatched = hist.data.map(r => r.movie_id);
  if(prog.data) prog.data.forEach(r => { FM.continueWatching[r.movie_id] = { position: Number(r.position_seconds), duration: Number(r.duration_seconds) || null }; });
}

/* ---------------- Favorites / Watchlist ---------------- */

async function toggleFavorite(movieId){
  if(!FM.user) return { ok:false, needsLogin:true };
  if(FM.favorites.has(movieId)){
    const { error } = await supabaseClient.from("favorites").delete().eq("user_id", FM.user.id).eq("movie_id", movieId);
    if(error) return { ok:false, message: error.message };
    FM.favorites.delete(movieId);
    return { ok:true, active:false };
  }
  const { error } = await supabaseClient.from("favorites").insert({ user_id: FM.user.id, movie_id: movieId });
  if(error) return { ok:false, message: error.message };
  FM.favorites.add(movieId);
  return { ok:true, active:true };
}

async function toggleWatchlist(movieId){
  if(!FM.user) return { ok:false, needsLogin:true };
  if(FM.watchlist.has(movieId)){
    const { error } = await supabaseClient.from("watchlist").delete().eq("user_id", FM.user.id).eq("movie_id", movieId);
    if(error) return { ok:false, message: error.message };
    FM.watchlist.delete(movieId);
    return { ok:true, active:false };
  }
  const { error } = await supabaseClient.from("watchlist").insert({ user_id: FM.user.id, movie_id: movieId });
  if(error) return { ok:false, message: error.message };
  FM.watchlist.add(movieId);
  return { ok:true, active:true };
}

/* ---------------- Recently Watched / Continue Watching ---------------- */

/** Upserts a "watched" row (bumps watched_at if it already exists — never duplicates). */
async function recordWatched(movieId){
  if(!FM.user) return;
  const { error } = await supabaseClient.from("watch_history").upsert(
    { user_id: FM.user.id, movie_id: movieId, watched_at: new Date().toISOString() },
    { onConflict: "user_id,movie_id" }
  );
  if(!error) FM.recentlyWatched = [movieId, ...FM.recentlyWatched.filter(x => x !== movieId)].slice(0, 30);
}

/** Saves playback position. Once >=95% complete, removes the progress row and logs it as watched instead. */
async function saveProgress(movieId, positionSeconds, durationSeconds){
  if(!FM.user || !durationSeconds) return;
  const ratio = positionSeconds / durationSeconds;
  if(ratio >= 0.95){
    await supabaseClient.from("watch_progress").delete().eq("user_id", FM.user.id).eq("movie_id", movieId);
    delete FM.continueWatching[movieId];
    await recordWatched(movieId);
    return;
  }
  const { error } = await supabaseClient.from("watch_progress").upsert(
    { user_id: FM.user.id, movie_id: movieId, position_seconds: positionSeconds, duration_seconds: durationSeconds, updated_at: new Date().toISOString() },
    { onConflict: "user_id,movie_id" }
  );
  if(!error) FM.continueWatching[movieId] = { position: positionSeconds, duration: durationSeconds };
}

async function removeProgress(movieId){
  if(!FM.user) return;
  await supabaseClient.from("watch_progress").delete().eq("user_id", FM.user.id).eq("movie_id", movieId);
  delete FM.continueWatching[movieId];
}
