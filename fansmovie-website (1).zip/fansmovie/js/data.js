/* =========================================================
   FansMovie — sample data
   All titles/posters below are PLACEHOLDER/SAMPLE content
   for prototype purposes only. Posters are generated on the
   fly (SVG) so no copyrighted artwork is used anywhere.
   Replace with real, licensed catalog data + real media URLs
   when the backend is connected (see admin.html notes).
   ========================================================= */

const GENRE_COLORS = {
  Action: ["#7a2b2b", "#2b1414"],
  Drama: ["#2b3a52", "#12161f"],
  Comedy: ["#7a5a1f", "#241a08"],
  Thriller: ["#2f2b52", "#131126"],
  Romance: ["#6b2b52", "#1f0f1a"],
  Fantasy: ["#245a4a", "#0f1f1a"],
  Crime: ["#3a3a3a", "#141414"],
  "Sci-Fi": ["#1f4a5a", "#0a1a20"],
};

function posterDataUrl(title, genre){
  const colors = GENRE_COLORS[genre] || ["#3a3a4a", "#15151d"];
  const words = title.split(" ");
  const initials = (words[0][0] + (words[1] ? words[1][0] : "")).toUpperCase();
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="300" height="450">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${colors[0]}"/>
        <stop offset="100%" stop-color="${colors[1]}"/>
      </linearGradient>
    </defs>
    <rect width="300" height="450" fill="url(#g)"/>
    <text x="150" y="240" font-family="Georgia, serif" font-size="90" fill="rgba(255,255,255,0.14)"
      text-anchor="middle" font-weight="700">${initials}</text>
  </svg>`;
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

/* category: bollywood | hollywood | south | webseries
   language values are used for the "Hindi Dubbed / Tamil / Telugu / Punjabi" filters */
const MOVIES = [
  { id: 1, title: "Monsoon Heist", year: 2024, language: "Hindi", category: "bollywood", genre: "Action", duration: "2h 12m", rating: 7.4, tier: "free", desc: "A crew of amateur thieves plan one last job during Mumbai's biggest festival night — sample synopsis for demo purposes.", trending:true, popular:true, featured:true },
  { id: 2, title: "Silence of Kites", year: 2023, language: "Hindi", category: "bollywood", genre: "Drama", duration: "2h 05m", rating: 8.1, tier: "premium", desc: "A retired judge revisits a decades-old case after a chance encounter. Placeholder description for the prototype.", trending:true, recent:true },
  { id: 3, title: "Iron Horizon", year: 2024, language: "English", category: "hollywood", genre: "Sci-Fi", duration: "2h 20m", rating: 7.8, tier: "free", desc: "A salvage crew discovers a signal from a ship that vanished thirty years ago. Sample content only.", featured:true, popular:true },
  { id: 4, title: "Nightfall Protocol", year: 2022, language: "English", category: "hollywood", genre: "Thriller", duration: "1h 58m", rating: 7.2, tier: "free", desc: "An analyst uncovers a conspiracy that reaches her own agency. Demo synopsis.", latest:true },
  { id: 5, title: "Vetri Kanavu", year: 2024, language: "Tamil", category: "south", genre: "Action", duration: "2h 30m", rating: 8.3, tier: "free", desc: "A small-town mechanic is pulled into the city's underground racing scene. Placeholder text.", trending:true, featured:true },
  { id: 6, title: "Chinna Kadhal", year: 2023, language: "Tamil", category: "south", genre: "Romance", duration: "2h 08m", rating: 7.6, tier: "free", desc: "Two strangers keep meeting at the same train station over one year. Sample synopsis.", popular:true },
  { id: 7, title: "Bhale Bujji", year: 2024, language: "Telugu", category: "south", genre: "Comedy", duration: "2h 15m", rating: 7.0, tier: "free", desc: "A wedding planner's chaotic week before her own wedding. Demo description.", latest:true, recent:true },
  { id: 8, title: "Simha Gadha", year: 2022, language: "Telugu", category: "south", genre: "Action", duration: "2h 25m", rating: 7.9, tier: "premium", desc: "A village elder's grandson returns to settle an old family dispute. Placeholder only.", popular:true },
  { id: 9, title: "Dil Diyan Gallan", year: 2024, language: "Punjabi", category: "south", genre: "Romance", duration: "1h 50m", rating: 7.3, tier: "free", desc: "Childhood friends navigate love, family and farmland inheritance. Sample synopsis.", recent:true },
  { id:10, title: "The Last Signal", year: 2021, language: "English", category: "hollywood", genre: "Sci-Fi", duration: "2h 02m", rating: 8.0, tier: "premium", desc: "Earth's last listening station picks up a message with days left to respond. Demo text.", trending:true },
  { id:11, title: "Rangeen Sheher (Hindi Dubbed)", year: 2023, language: "Hindi Dubbed", category: "south", genre: "Drama", duration: "2h 10m", rating: 7.5, tier: "free", desc: "A street painter's mural becomes the center of a city-wide movement. Placeholder synopsis.", latest:true },
  { id:12, title: "Kaale Baadal", year: 2024, language: "Hindi", category: "bollywood", genre: "Thriller", duration: "2h 00m", rating: 7.1, tier: "free", desc: "A weather scientist and a journalist race to warn a coastal town. Sample description.", recent:true },
  { id:13, title: "Rustpunk", year: 2024, language: "English", category: "hollywood", genre: "Fantasy", duration: "2h 18m", rating: 7.7, tier: "free", desc: "In a city built on an old machine, a scavenger finds a working heart of the engine. Demo text.", featured:true, trending:true },
  { id:14, title: "Office Undercover", year: 2023, language: "English", category: "webseries", genre: "Comedy", duration: "8 episodes", rating: 7.4, tier: "free", desc: "A workplace comedy about a very ordinary team with a very unusual client. Placeholder synopsis.", popular:true, latest:true },
  { id:15, title: "Zameen Ka Rang", year: 2024, language: "Hindi", category: "webseries", genre: "Crime", duration: "6 episodes", rating: 8.2, tier: "premium", desc: "A land dispute in a small district unravels into something much larger. Sample content.", trending:true, recent:true },
  { id:16, title: "Cold Harbour", year: 2022, language: "English", category: "webseries", genre: "Thriller", duration: "10 episodes", rating: 8.4, tier: "premium", desc: "A coastal town's fishing fleet goes quiet one by one. Demo description only.", popular:true },
];

MOVIES.forEach(m => { m.poster = posterDataUrl(m.title, m.genre); });

/* Sample streaming/trailer sources — public-domain demo clips only.
   Real catalog titles must point to properly licensed video URLs. */
const DEMO_VIDEO = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
const DEMO_TRAILER = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4";

function getMovieById(id){
  return MOVIES.find(m => String(m.id) === String(id));
}

/* Generic "missing poster" fallback — used via onerror on poster <img>
   tags site-wide, so a broken/unreachable poster_url (typo, deleted
   file, dead link) never shows a broken-image icon in production. */
const FALLBACK_POSTER = posterDataUrl("No Poster", "Drama");
