-- =========================================================
-- FansMovie — Supabase schema
-- Run this once in: Supabase Dashboard → SQL Editor → New query
-- =========================================================

-- 1. MOVIES TABLE ------------------------------------------------
create table public.movies (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  description  text,
  poster_url   text,
  trailer_url  text,
  video_url    text,
  year         int,
  language     text,
  genre        text,
  category     text not null check (category in ('bollywood','hollywood','south','webseries')),
  duration     text,
  rating       numeric(3,1) default 0 check (rating >= 0 and rating <= 10),
  tier         text not null default 'free' check (tier in ('free','premium')),
  published    boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

comment on column public.movies.category is 'Matches the site''s existing filters: bollywood, hollywood, south, webseries';
comment on column public.movies.published is 'Only published=true rows are shown on the public site';

-- keep updated_at current on every edit
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger movies_set_updated_at
before update on public.movies
for each row execute function public.set_updated_at();


-- 2. ADMINS TABLE --------------------------------------------------
-- A whitelist of auth users allowed to manage the catalog.
-- Rows here are added manually by you (the owner) in the SQL editor —
-- there is no public/self sign-up path to become an admin.
create table public.admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);


-- 3. ROW LEVEL SECURITY --------------------------------------------
alter table public.movies enable row level security;
alter table public.admins enable row level security;

-- Public (including logged-out visitors) can read PUBLISHED movies only.
create policy "public_read_published_movies"
on public.movies for select
to anon, authenticated
using (published = true);

-- Admins can read every movie, published or not.
create policy "admin_read_all_movies"
on public.movies for select
to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Admins can add movies.
create policy "admin_insert_movies"
on public.movies for insert
to authenticated
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Admins can edit movies (including toggling published/unpublished).
create policy "admin_update_movies"
on public.movies for update
to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Admins can delete movies.
create policy "admin_delete_movies"
on public.movies for delete
to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- A signed-in user may only check their OWN admin membership
-- (used by the front-end to confirm "am I an admin?").
create policy "admin_read_own_membership"
on public.admins for select
to authenticated
using (user_id = auth.uid());

-- No insert/update/delete policies exist on public.admins at all —
-- that's intentional. The only way to grant admin access is for you
-- to run an INSERT as the project owner in the SQL editor (step 4
-- of SETUP.md), which bypasses RLS. No website visitor, including a
-- signed-in one, can ever grant themselves admin access.
