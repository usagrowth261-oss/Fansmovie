// =========================================================
// FansMovie — Supabase Edge Function: stripe-webhook
// NOT DEPLOYED YET. This is source code for you (or a developer)
// to review and deploy — see SETUP.md "Step 5" for exact commands.
//
// Stripe calls this URL directly (never the browser) whenever a
// payment/subscription event happens. It verifies the request really
// came from Stripe using the webhook signing secret, then writes the
// result to `subscriptions` / `transactions` using the Supabase
// service-role key. This is the ONLY place (besides the controlled
// admin_grant_subscription() SQL function) that ever writes to those
// tables — see step5-premium.sql for why that matters.
// =========================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14?target=deno";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") ?? "", {
  apiVersion: "2023-10-16",
  httpClient: Stripe.createFetchHttpClient(),
});

const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

Deno.serve(async (req) => {
  const signature = req.headers.get("Stripe-Signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    // constructEventAsync (not constructEvent) is required on Deno's runtime.
    event = await stripe.webhooks.constructEventAsync(body, signature ?? "", webhookSecret);
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return new Response("Invalid signature", { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.supabase_user_id ?? session.client_reference_id;
        const planId = session.metadata?.plan_id;
        if (!userId || !session.subscription) break;

        const stripeSub = await stripe.subscriptions.retrieve(session.subscription as string);
        await upsertActiveSubscription(userId, planId ?? null, stripeSub, session.customer as string);
        await recordTransaction({
          userId,
          planId: planId ?? null,
          amount: (session.amount_total ?? 0) / 100,
          currency: (session.currency ?? "usd").toUpperCase(),
          status: "succeeded",
          providerTransactionId: session.id,
        });
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        const userId = invoice.subscription_details?.metadata?.supabase_user_id;
        const planId = invoice.subscription_details?.metadata?.plan_id ?? null;
        if (!userId) break;

        if (invoice.subscription) {
          const stripeSub = await stripe.subscriptions.retrieve(invoice.subscription as string);
          await upsertActiveSubscription(userId, planId, stripeSub, invoice.customer as string);
        }
        await recordTransaction({
          userId,
          planId,
          amount: (invoice.amount_paid ?? 0) / 100,
          currency: (invoice.currency ?? "usd").toUpperCase(),
          status: "succeeded",
          providerTransactionId: invoice.id,
        });
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const userId = invoice.subscription_details?.metadata?.supabase_user_id;
        const planId = invoice.subscription_details?.metadata?.plan_id ?? null;
        if (!userId) break;
        await recordTransaction({
          userId,
          planId,
          amount: (invoice.amount_due ?? 0) / 100,
          currency: (invoice.currency ?? "usd").toUpperCase(),
          status: "failed",
          providerTransactionId: invoice.id,
        });
        // Deliberately not touching `subscriptions.status` here — Stripe
        // retries failed invoices on its own schedule. We downgrade access
        // only once Stripe tells us the subscription itself is cancelled/
        // unpaid, via customer.subscription.updated/deleted below.
        break;
      }

      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const stripeSub = event.data.object as Stripe.Subscription;
        const userId = stripeSub.metadata?.supabase_user_id;
        if (!userId) break;

        const status = mapStripeStatus(stripeSub.status, event.type);
        await admin
          .from("subscriptions")
          .update({
            status,
            current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq("provider_subscription_id", stripeSub.id);
        break;
      }

      default:
        // Other event types are ignored on purpose — this handler only
        // implements what FansMovie's subscription model needs.
        break;
    }
  } catch (err) {
    console.error("Error handling webhook event:", err);
    return new Response("Webhook handler error", { status: 500 });
  }

  return new Response(JSON.stringify({ received: true }), { status: 200 });
});

async function upsertActiveSubscription(
  userId: string,
  planId: string | null,
  stripeSub: Stripe.Subscription,
  customerId: string,
) {
  await admin.from("subscriptions").update({ status: "expired" }).eq("user_id", userId).eq("status", "active");
  await admin.from("subscriptions").upsert(
    {
      user_id: userId,
      plan_id: planId,
      status: "active",
      current_period_start: new Date(stripeSub.current_period_start * 1000).toISOString(),
      current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString(),
      payment_provider: "stripe",
      provider_customer_id: customerId,
      provider_subscription_id: stripeSub.id,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "provider_subscription_id" },
  );
}

async function recordTransaction(t: {
  userId: string; planId: string | null; amount: number; currency: string;
  status: "succeeded" | "failed"; providerTransactionId: string;
}) {
  // The unique index on (payment_provider, provider_transaction_id) in
  // step5-premium.sql makes this safe against Stripe re-delivering the
  // same webhook event more than once.
  await admin.from("transactions").upsert(
    {
      user_id: t.userId,
      plan_id: t.planId,
      amount: t.amount,
      currency: t.currency,
      status: t.status,
      payment_provider: "stripe",
      provider_transaction_id: t.providerTransactionId,
    },
    { onConflict: "payment_provider,provider_transaction_id" },
  );
}

function mapStripeStatus(stripeStatus: Stripe.Subscription.Status, eventType: string): string {
  if (eventType === "customer.subscription.deleted") return "cancelled";
  if (stripeStatus === "active" || stripeStatus === "trialing") return "active";
  if (stripeStatus === "canceled") return "cancelled";
  return "expired"; // past_due, unpaid, incomplete_expired, etc.
}
