// =========================================================
// FansMovie — Supabase Edge Function: create-checkout-session
// NOT DEPLOYED YET. This is source code for you (or a developer)
// to review and deploy — see SETUP.md "Step 5" for exact commands.
//
// Called from premium.html via supabase.functions.invoke(). Creates a
// Stripe Checkout Session for the signed-in user and the plan they
// picked, and returns the URL to redirect them to. The Stripe SECRET
// key lives only in this function's environment (an Edge Function
// secret) — it is never sent to the browser.
// =========================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14?target=deno";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") ?? "", {
  apiVersion: "2023-10-16",
  httpClient: Stripe.createFetchHttpClient(),
});

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const SITE_URL = Deno.env.get("SITE_URL") ?? ""; // e.g. https://your-fansmovie-domain.com

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    // Identify the caller from their Supabase auth JWT (sent automatically
    // by supabase.functions.invoke() on the client).
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseAsUser = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await supabaseAsUser.auth.getUser();
    if (userErr || !userData?.user) {
      return json({ error: "Not signed in." }, 401);
    }
    const user = userData.user;

    const { planId } = await req.json();
    if (!planId) return json({ error: "planId is required." }, 400);

    // Service-role client for reads/writes that must bypass RLS (this
    // function IS the trusted backend — that's the point of Edge Functions).
    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: plan, error: planErr } = await admin
      .from("subscription_plans")
      .select("*")
      .eq("id", planId)
      .eq("active", true)
      .single();
    if (planErr || !plan) return json({ error: "Plan not found or inactive." }, 404);
    if (!plan.provider_price_id) {
      return json({ error: "This plan has no Stripe Price ID configured yet. See SETUP.md Step 5." }, 400);
    }

    // Reuse an existing Stripe customer for this user if we have one on file.
    const { data: existingSub } = await admin
      .from("subscriptions")
      .select("provider_customer_id")
      .eq("user_id", user.id)
      .not("provider_customer_id", "is", null)
      .limit(1)
      .maybeSingle();

    const customerId = existingSub?.provider_customer_id ?? undefined;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      client_reference_id: user.id,
      line_items: [{ price: plan.provider_price_id, quantity: 1 }],
      success_url: `${SITE_URL}/account.html?checkout=success`,
      cancel_url: `${SITE_URL}/premium.html?checkout=cancelled`,
      metadata: { supabase_user_id: user.id, plan_id: plan.id },
      subscription_data: { metadata: { supabase_user_id: user.id, plan_id: plan.id } },
    });

    return json({ url: session.url });
  } catch (err) {
    console.error(err);
    return json({ error: "Checkout session creation failed." }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
